import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize database
const dbPath = path.join(__dirname, '../concursabot.db');
const db = new Database(dbPath);

// Enable WAL mode for better concurrency and performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Initialize database schema
function initDB() {
    db.exec(`
        -- Chat sessions and messages
        CREATE TABLE IF NOT EXISTS chat_sessions (
            id TEXT PRIMARY KEY,
            subject TEXT NOT NULL,
            title TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS chat_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('user', 'model')),
            text TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE
        );

        -- Questions and answers tracking
        CREATE TABLE IF NOT EXISTS questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL,
            topic TEXT,
            banca TEXT,
            type TEXT DEFAULT 'multiple_choice',
            question_text TEXT NOT NULL,
            options TEXT NOT NULL, -- JSON array
            correct_index INTEGER NOT NULL,
            explanation TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS question_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id INTEGER NOT NULL,
            selected_answer INTEGER NOT NULL,
            is_correct BOOLEAN NOT NULL,
            answered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (question_id) REFERENCES questions(id)
        );

        -- Simulados (mock exams)
        CREATE TABLE IF NOT EXISTS simulados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            banca TEXT,
            subjects TEXT NOT NULL, -- JSON array
            question_count INTEGER NOT NULL,
            time_limit_minutes INTEGER,
            time_spent_seconds INTEGER,
            score INTEGER DEFAULT 0,
            status TEXT DEFAULT 'in_progress' CHECK(status IN ('in_progress', 'completed')),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            completed_at DATETIME
        );

        CREATE TABLE IF NOT EXISTS simulado_questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            simulado_id INTEGER NOT NULL,
            question_id INTEGER NOT NULL,
            selected_answer INTEGER,
            is_correct BOOLEAN,
            FOREIGN KEY (simulado_id) REFERENCES simulados(id) ON DELETE CASCADE,
            FOREIGN KEY (question_id) REFERENCES questions(id)
        );

        -- Summaries
        CREATE TABLE IF NOT EXISTS summaries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            original_text TEXT NOT NULL,
            summary TEXT NOT NULL,
            type TEXT DEFAULT 'strategic',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Edital analyses
        CREATE TABLE IF NOT EXISTS edital_analyses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cargo TEXT,
            edital_text TEXT NOT NULL,
            analysis TEXT NOT NULL, -- JSON
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Flashcard decks and cards
        CREATE TABLE IF NOT EXISTS flashcard_decks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            topic TEXT NOT NULL,
            subject TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS flashcards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            deck_id INTEGER NOT NULL,
            front TEXT NOT NULL,
            back TEXT NOT NULL,
            ease_factor REAL DEFAULT 2.5,
            interval_days INTEGER DEFAULT 0,
            repetitions INTEGER DEFAULT 0,
            next_review DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (deck_id) REFERENCES flashcard_decks(id) ON DELETE CASCADE
        );

        -- Study schedules
        CREATE TABLE IF NOT EXISTS schedules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            config TEXT NOT NULL, -- JSON (subjects, hoursPerDay, etc.)
            schedule_data TEXT NOT NULL, -- JSON (the generated schedule)
            exam_date TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS schedule_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            schedule_id INTEGER NOT NULL,
            day_of_week INTEGER,
            week_number INTEGER,
            subject TEXT NOT NULL,
            topic TEXT,
            duration_minutes INTEGER,
            completed BOOLEAN DEFAULT 0,
            completed_at DATETIME,
            FOREIGN KEY (schedule_id) REFERENCES schedules(id) ON DELETE CASCADE
        );

        -- Daily activity log for dashboard
        CREATE TABLE IF NOT EXISTS activity_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL, -- 'question', 'flashcard', 'simulado', 'summary', 'study', 'material'
            detail TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Study Room: uploaded PDF materials
        CREATE TABLE IF NOT EXISTS study_materials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            subject TEXT,
            lesson_number INTEGER,
            title TEXT,
            summary TEXT,
            content_text TEXT,       -- Full extracted text for contextual chat
            analysis_json TEXT,      -- JSON analysis from Gemini
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Study Room: study sessions with timer
        CREATE TABLE IF NOT EXISTS study_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            material_id INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            actual_duration_seconds INTEGER,
            status TEXT DEFAULT 'active' CHECK(status IN ('active', 'completed', 'paused')),
            scope_note TEXT, -- até onde o aluno marcou que chegou nesta sessão (escopo das questões de fixação)
            started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            completed_at DATETIME,
            FOREIGN KEY (material_id) REFERENCES study_materials(id) ON DELETE CASCADE
        );

        -- Study Room: fixation questions generated after session
        CREATE TABLE IF NOT EXISTS session_questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            material_id INTEGER NOT NULL,
            question_text TEXT NOT NULL,
            options TEXT NOT NULL,       -- JSON array
            correct_index INTEGER NOT NULL,
            explanation TEXT,
            difficulty TEXT DEFAULT 'medio',
            topic TEXT,
            selected_answer INTEGER,
            is_correct BOOLEAN,
            answered_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES study_sessions(id) ON DELETE CASCADE,
            FOREIGN KEY (material_id) REFERENCES study_materials(id)
        );

        -- Study Room: contextual chat during study session
        CREATE TABLE IF NOT EXISTS session_chat (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('user', 'model')),
            text TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES study_sessions(id) ON DELETE CASCADE
        );

        -- Missed Sessions / Backlog / Reposição de Matérias
        CREATE TABLE IF NOT EXISTS missed_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL,
            lesson_number INTEGER,
            title TEXT,
            reason TEXT,
            target_slot TEXT DEFAULT 'Hoje à noite',
            status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'completed')),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            resolved_at DATETIME
        );

        -- Spaced Repetition Reviews (D+1, D+7, D+30)
        CREATE TABLE IF NOT EXISTS study_reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            material_id INTEGER NOT NULL,
            subject TEXT NOT NULL,
            lesson_number INTEGER,
            review_type TEXT NOT NULL CHECK(review_type IN ('d1', 'd7', 'd30')),
            scheduled_date DATE NOT NULL,
            status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'completed', 'skipped')),
            completed_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (material_id) REFERENCES study_materials(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_reviews_date_status ON study_reviews(scheduled_date, status);

        -- RAG Knowledge Base: Documents and vector chunks
        CREATE TABLE IF NOT EXISTS rag_documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL UNIQUE,
            subject TEXT DEFAULT 'Geral',
            total_chunks INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS rag_chunks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            document_id INTEGER NOT NULL,
            chunk_index INTEGER NOT NULL,
            content TEXT NOT NULL,
            embedding TEXT NOT NULL, -- JSON array of floats (768 dimensions)
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (document_id) REFERENCES rag_documents(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_rag_chunks_doc ON rag_chunks(document_id);
    `);

    // Safe migration for existing databases
    try {
        const columns = db.pragma('table_info(study_materials)');
        const colNames = columns.map(c => c.name);
        
        if (!colNames.includes('lesson_number')) {
            db.exec('ALTER TABLE study_materials ADD COLUMN lesson_number INTEGER DEFAULT NULL;');
        }
        if (!colNames.includes('studied_at')) {
            db.exec('ALTER TABLE study_materials ADD COLUMN studied_at DATE DEFAULT NULL;');
        }
        if (!colNames.includes('theory_completed')) {
            db.exec('ALTER TABLE study_materials ADD COLUMN theory_completed BOOLEAN DEFAULT 0;');
        }
        if (!colNames.includes('questions_completed')) {
            db.exec('ALTER TABLE study_materials ADD COLUMN questions_completed BOOLEAN DEFAULT 0;');
        }
        if (!colNames.includes('caderno_enxuto')) {
            db.exec('ALTER TABLE study_materials ADD COLUMN caderno_enxuto TEXT DEFAULT NULL;');
        }
        
        db.exec('CREATE INDEX IF NOT EXISTS idx_materials_subject_lesson ON study_materials(subject, lesson_number);');
    } catch (e) {
        console.warn('Migration note:', e.message);
    }
}

initDB();

// Log activity wrapper
export function logActivity(type, detail) {
    try {
        const stmt = db.prepare('INSERT INTO activity_log (type, detail) VALUES (?, ?)');
        stmt.run(type, detail);
    } catch (err) {
        console.error('Failed to log activity:', err);
    }
}

export default db;
