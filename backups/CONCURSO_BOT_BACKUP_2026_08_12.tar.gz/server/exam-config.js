// Contexto do concurso-alvo do aluno. Editar este arquivo quando o edital sair
// (banca confirmada, disciplinas exatas, data da prova) — os prompts de Tutor e
// Sala de Estudos importam esta constante, então uma edição aqui já propaga pra tudo.
//
// Situação em 11/08/2026 (fonte: autorização do concurso, DOU 03/07/2026):
// vagas autorizadas para ATRFB, edital com prazo legal até 04/01/2027. Banca ainda
// NÃO confirmada oficialmente — FGV é a mais provável (foi a banca do edital de 2024),
// mas Cesgranrio também está no radar. Atualize a linha da banca assim que o edital sair.
export const TARGET_EXAM_CONTEXT = `
CONCURSO-ALVO DO ALUNO: Analista Tributário da Receita Federal do Brasil (ATRFB).
Vagas autorizadas em 03/07/2026; edital tem prazo legal para ser publicado até 04/01/2027.
Banca mais provável: FGV (foi a banca do último edital, em 2024) — ainda NÃO confirmada
oficialmente; Cesgranrio é a alternativa mais cotada. Priorize o estilo FGV como padrão,
mas não descarte o estilo Cesgranrio quando for razoável.
Bibliografia principal do aluno: curso completo da Estratégia Concursos para ATRFB.

DISCIPLINAS EM ROTAÇÃO ATIVA (Wave 1), por peso real na prova (banca FGV, edital anterior):
Direito Tributário (16q), Direito Previdenciário (16q), Língua Portuguesa (15q),
Fluência de Dados (15q — leitura/interpretação de dados, SQL básico, lógica de dados),
Direito Constitucional (14q), Legislação Tributária (14q), Legislação Aduaneira (14q).

DISCIPLINAS NA FILA (Wave 2, ainda sem bloco fixo de estudo):
Direito Administrativo (12q), Língua Inglesa (10q), Raciocínio Lógico Matemático (10q),
Estatística (10q), Contabilidade Geral (10q), Administração Geral e Pública (10q).

Não existem Direito Civil, Direito Penal, Direito do Trabalho, AFO, Auditoria ou
Contabilidade de Custos no programa deste cargo — não sugira ênfase nessas disciplinas.

HIERARQUIA DE MATERIAL (do aluno, use pra contextualizar respostas quando relevante):
Apostila "Grifada" > Apostila "Completa" > Apostila "Simplificada" > Passo Estratégico.
O Passo Estratégico e as Apostilas Completa/Grifada já vêm com questões comentadas
embutidas no próprio PDF — se o aluno perguntar sobre exercícios, lembre que as questões
já presentes no material que ele está lendo têm prioridade sobre questões geradas do zero.
`;
