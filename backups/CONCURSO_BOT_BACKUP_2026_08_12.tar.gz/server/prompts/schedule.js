export const scheduleSystemInstruction = `
Você é o mais experiente Mentor e Estrategista de Ciclos de Estudo para Concursos de Alto Nível (Receita Federal, Fisco, Tribunais e Polícia Federal).
Sua missão é gerar um Cronograma Semanal Inteligente e Implacável seguindo a metodologia exata do aluno:
1. De SEGUNDA a QUINTA: Ciclo de estudo focado nas matérias prioritárias da prova (teoria em apostila original + questões imediatas de fixação).
2. SEXTA-FEIRA À NOITE: Bloco fixo e obrigatório de "✍️ Treinamento de Redação / Questão Discursiva (Estilo FGV - Parecer e Estudo de Caso Prático)".
3. SÁBADO: Bloco fixo e obrigatório de "📚 Resumo Semanal Integrado & Mapa Mental Consolidado" (1 vez por semana para fechar o ciclo de tudo o que foi estudado na semana) + Revisão Geral.
4. DOMINGO: "🎯 Simulado Geral / Bateria de Questões por Banca" e Descanso Estratégico.

Idioma: PORTUGUÊS DO BRASIL.
`;

export const schedulePromptTemplate = (subjects, hoursPerDay, daysPerWeek, examDate) => `
Gere o Cronograma Semanal Estratégico (Semana Tipo) para um candidato à Receita Federal (ATRFB / AFRFB):

Parâmetros do aluno:
- Disciplinas do Ciclo: ${subjects.join(', ')}
- Horas disponíveis por dia de semana: ${hoursPerDay}h
- Dias de estudo por semana: ${daysPerWeek}
- Data da prova: ${examDate || 'A definir / Pré-Edital'}

REGRAS OBRIGATÓRIAS DO CICLO:
1. Sexta-feira à noite DEVE conter o bloco: "✍️ Redação & Questão Discursiva FGV (Estudo de Caso Tributário / Aduaneiro)".
2. Sábado DEVE conter o bloco: "📚 Resumo Semanal Integrado & Revisão Geral das Aulas da Semana".
3. Domingo: "🎯 Simulado Semanal da Banca FGV (ou descanso se dias/semana < 7)".
4. Distribua o tempo em minutos para cada dia (day_of_week de 1 a 7, onde 1 = Segunda-feira e 7 = Domingo).
`;

export const scheduleSchema = {
    type: 'OBJECT',
    properties: {
        schedule_data: {
            type: 'OBJECT',
            properties: {
                strategy_summary: { type: 'STRING', description: "Resumo da estratégia do ciclo semanal" }
            }
        },
        tasks: {
            type: 'ARRAY',
            items: {
                type: 'OBJECT',
                properties: {
                    day_of_week: { type: 'INTEGER', description: "1 (Segunda) a 7 (Domingo)" },
                    subject: { type: 'STRING' },
                    topic: { type: 'STRING', description: "Assunto específico, 'Redação Discursiva', 'Resumo Semanal' ou 'Exercícios'" },
                    duration_minutes: { type: 'INTEGER' }
                },
                required: ["day_of_week", "subject", "topic", "duration_minutes"]
            }
        }
    },
    required: ["schedule_data", "tasks"]
};
