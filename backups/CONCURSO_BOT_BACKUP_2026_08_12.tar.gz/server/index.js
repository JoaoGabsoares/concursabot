import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import multer from 'multer';
import fs from 'fs';
import db from './database.js';

// Load environment variables
dotenv.config();

// Import routes
import tutorRoutes from './routes/tutor.js';
import questionsRoutes from './routes/questions.js';
import simuladosRoutes from './routes/simulados.js';
import summariesRoutes from './routes/summaries.js';
import editalRoutes from './routes/edital.js';
import flashcardsRoutes from './routes/flashcards.js';
import scheduleRoutes from './routes/schedule.js';
import dashboardRoutes from './routes/dashboard.js';
import studyRoomRoutes from './routes/study-room.js';
import ragRoutes from './routes/rag.js';
import backlogRoutes from './routes/backlog.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
// Serve static files from 'public' directory
app.use(express.static(path.join(__dirname, '../public')));

// Multer config for PDF uploads
const uploadsDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
const upload = multer({
    storage: multer.diskStorage({
        destination: uploadsDir,
        filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
    }),
    fileFilter: (req, file, cb) => {
        if (file.mimetype === 'application/pdf') cb(null, true);
        else cb(new Error('Apenas arquivos PDF são aceitos.'), false);
    },
    limits: { fileSize: 20 * 1024 * 1024 } // 20MB
});

app.use('/api/study-room/upload', upload.single('pdf'));
app.use('/uploads', express.static(uploadsDir));

// Mount routes
app.use('/api/tutor', tutorRoutes);
app.use('/api/questions', questionsRoutes);
app.use('/api/simulados', simuladosRoutes);
app.use('/api/summaries', summariesRoutes);
app.use('/api/edital', editalRoutes);
app.use('/api/flashcards', flashcardsRoutes);
app.use('/api/schedule', scheduleRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/study-room', studyRoomRoutes);
app.use('/api/rag', ragRoutes);
app.use('/api/backlog', backlogRoutes);

// Basic error handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Erro interno no servidor' });
});

// Start server
const server = app.listen(PORT, () => {
    console.log(`ConcursaBot Backend rodando! Acesse: http://localhost:${PORT}`);
});

// Graceful shutdown
function gracefulShutdown(signal) {
    console.log(`\nEncerrando servidor (${signal})...`);
    server.close(() => {
        try {
            db.close();
            console.log('Conexão SQLite fechada com sucesso.');
        } catch (e) {}
        process.exit(0);
    });
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
