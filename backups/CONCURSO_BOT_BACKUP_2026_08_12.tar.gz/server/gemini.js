import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
    console.warn("Aviso: GEMINI_API_KEY não encontrada no arquivo .env");
}

const ai = new GoogleGenAI({ apiKey: apiKey });
// gemini-2.0-flash foi desligado em 01/06/2026. gemini-3.6-flash é o modelo Flash estável atual (GA).
const DEFAULT_MODEL = process.env.GEMINI_MODEL || 'gemini-3.6-flash';
// text-embedding-004 foi desligado em 14/01/2026. gemini-embedding-001 é o substituto oficial.
const DEFAULT_EMBEDDING_MODEL = process.env.GEMINI_EMBEDDING_MODEL || 'gemini-embedding-001';
// gemini-embedding-001 tem 3072 dimensões por padrão; fixamos em 768 via MRL para
// manter compatibilidade com o schema do banco (rag_chunks.embedding documentado como 768-d).
const EMBEDDING_OUTPUT_DIMENSIONALITY = 768;

async function generateContent(prompt, systemInstruction, model = DEFAULT_MODEL) {
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                systemInstruction: systemInstruction
            }
        });
        return response.text;
    } catch (error) {
        console.error("Erro na API do Gemini (generateContent):", error);
        throw error;
    }
}

async function generateJSON(prompt, systemInstruction, schema, model = DEFAULT_MODEL) {
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: 'application/json',
                responseSchema: schema
            }
        });
        return JSON.parse(response.text);
    } catch (error) {
        console.error("Erro na API do Gemini (generateJSON):", error);
        throw error;
    }
}

async function* streamChat(history, message, systemInstruction, model = DEFAULT_MODEL) {
    try {
        const chat = createChat(history, systemInstruction, model);
        const responseStream = await chat.sendMessageStream({ message: message });
        
        for await (const chunk of responseStream) {
            yield chunk.text;
        }
    } catch (error) {
        console.error("Erro na API do Gemini (streamChat):", error);
        throw error;
    }
}

function createChat(history = [], systemInstruction, model = DEFAULT_MODEL) {
    // History needs to be formatted for @google/genai chat
    const formattedHistory = history.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
    }));

    const config = {};
    if (systemInstruction) {
        config.systemInstruction = systemInstruction;
    }

    return ai.chats.create({
        model: model,
        history: formattedHistory,
        config: config
    });
}

// Generate vector embedding for RAG using gemini-embedding-001 (substituto do descontinuado text-embedding-004)
async function generateEmbedding(text, model = DEFAULT_EMBEDDING_MODEL) {
    try {
        const response = await ai.models.embedContent({
            model: model,
            contents: text,
            config: { outputDimensionality: EMBEDDING_OUTPUT_DIMENSIONALITY }
        });
        return response.embedding.values;
    } catch (error) {
        console.error("Erro na API do Gemini (generateEmbedding):", error);
        throw error;
    }
}

// Calculate Cosine Similarity between two embedding vectors
function cosineSimilarity(vecA, vecB) {
    if (!vecA || !vecB || vecA.length !== vecB.length) return 0;
    let dot = 0.0, normA = 0.0, normB = 0.0;
    for (let i = 0; i < vecA.length; i++) {
        dot += vecA[i] * vecB[i];
        normA += vecA[i] * vecA[i];
        normB += vecB[i] * vecB[i];
    }
    const denom = Math.sqrt(normA) * Math.sqrt(normB);
    return denom === 0 ? 0 : dot / denom;
}

export { generateContent, generateJSON, streamChat, createChat, generateEmbedding, cosineSimilarity };

