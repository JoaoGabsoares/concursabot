import express from 'express';
import db, { logActivity } from '../database.js';
import { generateJSON } from '../gemini.js';
import { questionsSystemInstruction, questionsPromptTemplate, questionsSchema } from '../prompts/questions.js';

const router = express.Router();

// POST /create - Generate a full mock exam
router.post('/create', async (req, res) => {
    const { banca = 'FGV', subjects, questionCount = 10, timeLimitMinutes = 60 } = req.body;

    if (!subjects || !Array.isArray(subjects) || subjects.length === 0) {
        return res.status(400).json({ error: 'Subjects array is required' });
    }

    try {
        const isCebraspe = banca.toUpperCase().includes('CEBRASPE') || banca.toUpperCase().includes('CESPE');
        const questionType = isCebraspe ? 'certo_errado' : 'multiple_choice';

        // Create simulado record first
        const simStmt = db.prepare(`
            INSERT INTO simulados (banca, subjects, question_count, time_limit_minutes) 
            VALUES (?, ?, ?, ?)
        `);
        const simInfo = simStmt.run(banca, JSON.stringify(subjects), questionCount, timeLimitMinutes);
        const simuladoId = simInfo.lastInsertRowid;

        // Generate questions per subject
        const questionsPerSubject = Math.max(1, Math.floor(questionCount / subjects.length));
        
        for (const subject of subjects) {
            const prompt = questionsPromptTemplate(subject, 'Tópicos mais cobrados em prova', banca, questionType, questionsPerSubject);
            const generatedData = await generateJSON(prompt, questionsSystemInstruction, questionsSchema);

            db.transaction(() => {
                const insertQ = db.prepare(`
                    INSERT INTO questions (subject, banca, type, question_text, options, correct_index, explanation)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                `);
                const insertSq = db.prepare('INSERT INTO simulado_questions (simulado_id, question_id) VALUES (?, ?)');

                for (const q of generatedData) {
                    const info = insertQ.run(
                        subject,
                        banca,
                        questionType,
                        q.question_text,
                        JSON.stringify(q.options),
                        q.correct_index,
                        q.explanation
                    );
                    insertSq.run(simuladoId, info.lastInsertRowid);
                }
            })();
        }

        res.json({ success: true, simuladoId, banca, questionType });
    } catch (error) {
        console.error("Create simulado error:", error);
        res.status(500).json({ error: error.message });
    }
});

// POST /:id/finish - Submit answers with support for Cebraspe negative penalty
router.post('/:id/finish', (req, res) => {
    const simuladoId = req.params.id;
    const { answers = {}, timeSpentSeconds = 0 } = req.body; // answers = { question_id: selected_index | -1 }

    try {
        const sim = db.prepare('SELECT * FROM simulados WHERE id = ?').get(simuladoId);
        if (!sim) return res.status(404).json({ error: 'Simulado não encontrado' });

        const isCebraspe = sim.banca && (sim.banca.toUpperCase().includes('CEBRASPE') || sim.banca.toUpperCase().includes('CESPE'));

        const getQuestions = db.prepare('SELECT sq.id, sq.question_id, q.correct_index FROM simulado_questions sq JOIN questions q ON sq.question_id = q.id WHERE sq.simulado_id = ?');
        const sqs = getQuestions.all(simuladoId);

        let acertos = 0;
        let erros = 0;
        let emBranco = 0;
        
        const updateSq = db.prepare('UPDATE simulado_questions SET selected_answer = ?, is_correct = ? WHERE id = ?');
        
        db.transaction(() => {
            for (const sq of sqs) {
                const selected = answers[sq.question_id];
                if (selected === undefined || selected === null || selected === -1) {
                    emBranco++;
                    updateSq.run(null, null, sq.id);
                } else {
                    const isCorrect = selected === sq.correct_index;
                    if (isCorrect) {
                        acertos++;
                    } else {
                        erros++;
                    }
                    updateSq.run(selected, isCorrect ? 1 : 0, sq.id);
                }
            }
            
            // Se Cebraspe: nota líquida = acertos - erros. Caso contrário: acertos.
            const liquidScore = isCebraspe ? Math.max(0, acertos - erros) : acertos;
            const finalScore = liquidScore;

            const updateSim = db.prepare('UPDATE simulados SET score = ?, time_spent_seconds = ?, status = ?, completed_at = CURRENT_TIMESTAMP WHERE id = ?');
            updateSim.run(finalScore, timeSpentSeconds || 0, 'completed', simuladoId);
        })();

        logActivity('simulado', `Concluiu Simulado ${sim.banca}: ${acertos} acertos, ${erros} erros, ${emBranco} em branco (Nota: ${isCebraspe ? acertos - erros : acertos}/${sqs.length})`);

        res.json({
            success: true,
            banca: sim.banca,
            isCebraspe,
            total: sqs.length,
            acertos,
            erros,
            emBranco,
            notaLiquida: acertos - erros,
            score: isCebraspe ? Math.max(0, acertos - erros) : acertos,
            accuracyPct: sqs.length > 0 ? Math.round((acertos / sqs.length) * 100) : 0
        });
    } catch (error) {
        console.error("Finish simulado error:", error);
        res.status(500).json({ error: error.message });
    }
});

// GET / - List all simulados
router.get('/', (req, res) => {
    try {
        const stmt = db.prepare('SELECT * FROM simulados ORDER BY created_at DESC');
        res.json(stmt.all());
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// GET /:id - Get full simulado
router.get('/:id', (req, res) => {
    try {
        const sim = db.prepare('SELECT * FROM simulados WHERE id = ?').get(req.params.id);
        if (!sim) return res.status(404).json({ error: 'Not found' });

        const qs = db.prepare(`
            SELECT sq.id as sq_id, sq.selected_answer, sq.is_correct, q.* 
            FROM simulado_questions sq 
            JOIN questions q ON sq.question_id = q.id 
            WHERE sq.simulado_id = ?
        `).all(req.params.id);

        res.json({ ...sim, questions: qs });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
