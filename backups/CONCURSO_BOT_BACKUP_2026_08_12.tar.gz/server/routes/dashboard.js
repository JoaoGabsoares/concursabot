import express from 'express';
import db from '../database.js';

const router = express.Router();

function getDashboardData(req, res) {
    try {
        // Questões
        const qStats = db.prepare(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN is_correct = 1 THEN 1 ELSE 0 END) as correct
            FROM question_answers
        `).get();

        // Flashcards
        const fStats = db.prepare(`
            SELECT 
                COUNT(*) as due
            FROM flashcards 
            WHERE next_review <= datetime('now')
        `).get();

        // Simulados
        const sStats = db.prepare(`
            SELECT 
                COUNT(*) as total,
                AVG(score) as avg_score
            FROM simulados 
            WHERE status = 'completed'
        `).get();

        // Subject stats (weakest/strongest)
        const subStats = db.prepare(`
            SELECT 
                q.subject,
                COUNT(qa.id) as total,
                SUM(CASE WHEN qa.is_correct = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(qa.id) as correct_pct
            FROM question_answers qa
            JOIN questions q ON qa.question_id = q.id
            GROUP BY q.subject
            HAVING total >= 5
            ORDER BY correct_pct ASC
        `).all();

        const weakest = subStats.slice(0, 3);
        const strongest = subStats.slice(-3).reverse();

        // Recent Activity
        const recentActivity = db.prepare(`
            SELECT * FROM activity_log 
            ORDER BY created_at DESC 
            LIMIT 10
        `).all();

        const totalAnswered = qStats?.total || 0;
        const correctCount = qStats?.correct || 0;
        const accuracyPct = totalAnswered > 0 ? Math.round((correctCount / totalAnswered) * 100) : 0;

        res.json({
            // Legacy / direct keys
            answered: totalAnswered,
            accuracy: accuracyPct,
            pendingCards: fStats?.due || 0,
            simulados: sStats?.total || 0,
            // Nested object keys
            questions: {
                totalAnswered,
                correctPct: accuracyPct
            },
            flashcards: {
                dueCount: fStats?.due || 0
            },
            simuladosStats: {
                totalCompleted: sStats?.total || 0,
                avgScore: sStats?.avg_score || 0
            },
            weakSubjects: weakest,
            strongSubjects: strongest,
            recentActivity
        });

    } catch (error) {
        console.error('Dashboard stats error:', error);
        res.status(500).json({ error: error.message });
    }
}

router.get('/', getDashboardData);
router.get('/stats', getDashboardData);

export default router;
