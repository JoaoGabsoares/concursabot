import { Router } from 'express';
import db from '../database.js';
import { generateEmbedding, cosineSimilarity, streamChat, generateContent } from '../gemini.js';

const router = Router();

// GET /stats — Return RAG knowledge base statistics
router.get('/stats', (req, res) => {
  try {
    const docCount = db.prepare('SELECT COUNT(*) as count FROM rag_documents').get().count;
    const chunkCount = db.prepare('SELECT COUNT(*) as count FROM rag_chunks').get().count;
    const subjects = db.prepare(`
      SELECT subject, COUNT(*) as count, SUM(total_chunks) as chunks 
      FROM rag_documents 
      GROUP BY subject
    `).all();

    res.json({
      totalDocuments: docCount,
      totalChunks: chunkCount,
      subjects: subjects
    });
  } catch (error) {
    console.error('Erro ao buscar stats RAG:', error);
    res.status(500).json({ error: 'Falha ao buscar estatísticas do RAG' });
  }
});

// GET /documents — List all indexed documents
router.get('/documents', (req, res) => {
  try {
    const docs = db.prepare(`
      SELECT id, filename, filepath, subject, total_chunks, created_at
      FROM rag_documents
      ORDER BY created_at DESC
    `).all();

    res.json({ documents: docs });
  } catch (error) {
    console.error('Erro ao listar documentos RAG:', error);
    res.status(500).json({ error: 'Falha ao listar documentos' });
  }
});

// Helper function: Semantic vector search across all chunks
async function performVectorSearch(query, topK = 5, subjectFilter = null) {
  const queryEmbedding = await generateEmbedding(query);

  let querySql = `
    SELECT rc.id, rc.document_id, rc.chunk_index, rc.content, rc.embedding,
           rd.filename, rd.subject
    FROM rag_chunks rc
    JOIN rag_documents rd ON rc.document_id = rd.id
  `;
  const params = [];

  if (subjectFilter && subjectFilter !== 'Todas') {
    querySql += ' WHERE rd.subject = ?';
    params.push(subjectFilter);
  }

  const allChunks = db.prepare(querySql).all(...params);

  // Compute similarity scores
  const scoredChunks = allChunks.map(chunk => {
    let emb;
    try {
      emb = JSON.parse(chunk.embedding);
    } catch (e) {
      emb = [];
    }

    const similarity = cosineSimilarity(queryEmbedding, emb);
    return {
      id: chunk.id,
      documentId: chunk.document_id,
      filename: chunk.filename,
      subject: chunk.subject,
      chunkIndex: chunk.chunk_index,
      content: chunk.content,
      score: similarity
    };
  });

  // Sort descending and take top K
  scoredChunks.sort((a, b) => b.score - a.score);
  return scoredChunks.slice(0, topK);
}

// POST /search — Semantic similarity search across indexed PDFs
router.post('/search', async (req, res) => {
  try {
    const { query, topK = 5, subject } = req.body;

    if (!query) {
      return res.status(400).json({ error: 'Query de busca é obrigatória' });
    }

    const results = await performVectorSearch(query, topK, subject);
    res.json({ query, results });
  } catch (error) {
    console.error('Erro na busca semântica RAG:', error);
    res.status(500).json({ error: 'Falha ao realizar busca semântica' });
  }
});

// POST /ask — Full RAG question answering citing multiple PDF sources
router.post('/ask', async (req, res) => {
  try {
    const { question, subject, stream = false } = req.body;

    if (!question) {
      return res.status(400).json({ error: 'Pergunta é obrigatória' });
    }

    // 1. Retrieve top 5 most relevant snippets from the entire 1000 PDF library
    const topSnippets = await performVectorSearch(question, 5, subject);

    if (topSnippets.length === 0) {
      return res.json({
        answer: 'Nenhum documento indexado na base de conhecimento RAG ainda. Execute a ingestão de PDFs primeiro.',
        sources: []
      });
    }

    // 2. Format context with source citations
    const contextText = topSnippets.map((s, idx) => `
[FONTE ${idx + 1}]: Arquivo "${s.filename}" (${s.subject})
${s.content}
`).join('\n---\n');

    // 3. Construct Augmented Prompt
    const ragPrompt = `Você é o Tutor IA Especialista do ConcursaBot com acesso à base completa de conhecimento (RAG) de PDFs do aluno.

Responda à dúvida do aluno fundamentando sua resposta nos trechos fornecidos abaixo.
Sempre cite de quais arquivos/fontes você extraiu as informações (ex: Conforme o material "Aula02_Tributario.pdf"...).
Se os trechos não responderem completamente, use seu conhecimento geral para complementar de forma clara.

DÚVIDA DO ALUNO:
${question}

TRECHOS RELEVANTES RECUPERADOS DOS PDFS:
${contextText}
`;

    if (stream) {
      // Stream response via SSE
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');

      // Send sources first
      res.write(`data: ${JSON.stringify({ sources: topSnippets.map(s => ({ filename: s.filename, subject: s.subject, score: Math.round(s.score * 100) })) })}\n\n`);

      try {
        for await (const chunk of streamChat([], ragPrompt, 'Você é um professor de concursos especialista com suporte a RAG.')) {
          if (chunk) {
            res.write(`data: ${JSON.stringify({ chunk })}\n\n`);
          }
        }
      } catch (streamErr) {
        console.error('Erro no streaming RAG:', streamErr);
      }

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } else {
      const answer = await generateContent(ragPrompt, 'Você é um professor de concursos especialista com suporte a RAG.');
      res.json({
        answer,
        sources: topSnippets.map(s => ({
          filename: s.filename,
          subject: s.subject,
          score: Math.round(s.score * 100),
          snippet: s.content.substring(0, 150) + '...'
        }))
      });
    }

  } catch (error) {
    console.error('Erro no RAG Q&A:', error);
    res.status(500).json({ error: 'Falha ao processar pergunta com RAG' });
  }
});

// DELETE /documents/:id — Delete a document and its vector chunks
router.delete('/documents/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM rag_documents WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (error) {
    console.error('Erro ao deletar documento RAG:', error);
    res.status(500).json({ error: 'Falha ao deletar documento' });
  }
});

export default router;
