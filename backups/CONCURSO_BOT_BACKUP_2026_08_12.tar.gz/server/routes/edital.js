import express from 'express';
import db from '../database.js';
import { generateJSON } from '../gemini.js';
import { editalSystemInstruction, editalPromptTemplate, editalSchema } from '../prompts/edital.js';

const router = express.Router();

// Presets pré-configurados dos maiores concursos públicos do país
const PRESETS = [
    {
        id: 'receita-atrfb-fgv',
        cargo: 'Analista Tributário da Receita Federal (ATRFB)',
        banca: 'FGV',
        descricao: 'Edital oficial mais recente com 140 questões (Wave 1: Tributário, Previdenciário, Português, Fluência de Dados, Constitucional, Leg. Tributária, Leg. Aduaneira).',
        editalText: `
CONHECIMENTOS BÁSICOS E ESPECÍFICOS - ANALISTA TRIBUTÁRIO DA RECEITA FEDERAL (ATRFB):

1. DIREITO TRIBUTÁRIO (16 questões - FGV):
Conceito e classificação dos tributos. Competência tributária. Limitações constitucionais ao poder de tributar (Princípios e Imunidades). Súmulas Vinculantes do STF e jurisprudência pacificada. Legislação tributária: vigência, aplicação, interpretação e integração. Fato gerador e obrigação tributária principal e acessória. Responsabilidade tributária (sucessão, terceiros e responsabilidade pessoal art. 135 do CTN). Crédito tributário: constituição, lançamento e modalidades. Suspensão da exigibilidade do crédito tributário (art. 151 CTN). Extinção do crédito tributário (art. 156 CTN, decadência e prescrição). Exclusão do crédito tributário (isenção e anistia). Garantias e privilégios do crédito tributário. Administração tributária: fiscalização, dívida ativa e certidões negativas. Reforma Tributária (EC 132/2023, IBS, CBS e Imposto Seletivo).

2. DIREITO PREVIDENCIÁRIO (16 questões - FGV):
Seguridade Social na CF/88: Saúde, Previdência e Assistência Social. Princípios e diretrizes constitucionais. Regime Geral de Previdência Social (RGPS - Lei 8.212/91 e Lei 8.213/91). Segurados obrigatórios e facultativos. Financiamento da Seguridade Social: contribuições dos segurados, empresas, empregadores domésticos e outras fontes. Salário de contribuição e base de cálculo. Arrecadação e recolhimento das contribuições. Isenções e imunidades para entidades beneficentes. Benefícios do RGPS: aposentadorias, auxílios, pensões e salário-maternidade. Manutenção e perda da qualidade de segurado (período de graça).

3. LÍNGUA PORTUGUESA (15 questões - FGV):
Compreensão e interpretação de textos de gêneros variados. Reconhecimento de tipos e gêneros textuais. Domínio da ortografia oficial e acentuação gráfica. Emprego do sinal indicativo de crase. Mecanismos de coesão textual e referenciação. Relações de coordenação e subordinação entre orações. Sintaxe da oração e do período. Concordância verbal e nominal (casos clássicos da FGV). Regência verbal e nominal. Emprego e colocação dos pronomes átonos. Pontuação e efeitos de sentido. Reescritura de frases e paráfrase. Variação linguística e adequação vocabular.

4. FLUÊNCIA EM DADOS (15 questões - FGV):
Conceitos fundamentais de banco de dados e modelagem relacional. Modelo Entidade-Relacionamento (MER) e normalização (1FN, 2FN, 3FN). Linguagem SQL (DDL, DML, DQL: SELECT, JOINs, GROUP BY, HAVING, subqueries e window functions). Noções de Data Warehouse, Data Lake, ETL e OLAP. Conceitos de Big Data (Volume, Variedade, Velocidade, Veracidade e Valor). Governança de Dados (DAMA-DMBOK) e Lei Geral de Proteção de Dados (LGPD). Visualização de dados e conceitos básicos de aprendizado de máquina.

5. DIREITO CONSTITUCIONAL (14 questões - FGV):
Princípios fundamentais da CF/88. Direitos e garantias fundamentais: direitos e deveres individuais e coletivos (art. 5º), direitos sociais, nacionalidade e direitos políticos. Remédios constitucionais (Habeas Corpus, Mandado de Segurança, Mandado de Injunção, Habeas Data e Ação Popular). Organização do Estado: União, Estados, DF e Municípios. Repartição de competências legislativas e materiais. Administração Pública (arts. 37 a 41). Organização dos Poderes: Poder Legislativo (processo legislativo), Poder Executivo e Poder Judiciário (STF, STJ e Tribunais Federais). Funções essenciais à Justiça. Controle de Constitucionalidade (difuso e concentrado - ADI, ADC, ADO, ADPF).

6. LEGISLAÇÃO TRIBUTÁRIA FEDERAL (14 questões - FGV):
Imposto sobre a Renda e Proventos de Qualquer Natureza (IRPF e IRPJ): fato gerador, contribuintes, responsáveis, base de cálculo e regimes de apuração (Lucro Real, Presumido e Arbitrado). Imposto sobre Produtos Industrializados (IPI): fato gerador, base de cálculo, não cumulatividade e incentivos fiscais. Contribuição para o PIS/PASEP e COFINS (regimes cumulativo e não cumulativo). Imposto sobre Operações Financeiras (IOF). Imposto sobre a Propriedade Territorial Rural (ITR). Simples Nacional (LC 123/2006).

7. LEGISLAÇÃO ADUANEIRA (14 questões - FGV):
Jurisdição e controle aduaneiro. Território aduaneiro (zona primária e secundária). Administração Aduaneira. Imposto de Importação (II) e Imposto de Exportação (IE): fato gerador, base de cálculo, regimes e contribuintes. Procedimento de importação e exportação (Despacho Aduaneiro, declaração e conferência aduaneira). Regimes Aduaneiros Especiais (Trânsito Aduaneiro, Admissão Temporária, Drawback, Entreposto Aduaneiro e Recof). Infrações e penalidades aduaneiras (Pena de Perdimento de bens, veículos e moeda). Sistema Integrado de Comércio Exterior (SISCOMEX) e Portal Único Siscomex.
        `
    },
    {
        id: 'receita-afrfb-fgv',
        cargo: 'Auditor Fiscal da Receita Federal (AFRFB)',
        banca: 'FGV',
        descricao: 'Edital completo de Auditor Fiscal com Auditoria, Contabilidade Avançada, TI e Comércio Internacional.',
        editalText: `
AUDITOR FISCAL DA RECEITA FEDERAL DO BRASIL (AFRFB) - BANCA FGV:
Disciplinas: Direito Tributário, Legislação Tributária, Legislação Aduaneira, Direito Constitucional, Direito Administrativo, Direito Previdenciário, Língua Portuguesa, Fluência em Dados, Auditoria Fiscal e Contábil, Contabilidade Geral e Avançada, Administração Geral e Pública, Comércio Internacional, Raciocínio Lógico e Estatística, Língua Inglesa.
Foco em casos práticos de fiscalização, lançamentos de ofício, autos de infração, Súmulas do CARF e STJ/STF.
        `
    },
    {
        id: 'pf-agente-cebraspe',
        cargo: 'Agente da Polícia Federal',
        banca: 'CEBRASPE',
        descricao: 'Edital clássico da PF com 120 itens Certo/Errado focado em TI/Informática (36 itens), Contabilidade (24 itens), Português (24 itens) e Direito.',
        editalText: `
POLÍCIA FEDERAL (AGENTE) - CEBRASPE (CESPE):
Bloco I (60 itens): Língua Portuguesa, Direito Administrativo, Direito Constitucional, Direito Penal e Processual Penal, Legislação Especial, Estatística, RLM.
Bloco II (36 itens): Informática (Banco de Dados, Redes, Segurança da Informação, Python/R, Sistemas Operacionais).
Bloco III (24 itens): Contabilidade Geral (Escrituração, Balanço Patrimonial, DRE, CPCs e Análise).
Formato: 120 itens Certo ou Errado com apenação líquida (1 errada anula 1 certa).
        `
    }
];

// GET /presets - Get available official presets
router.get('/presets', (req, res) => {
    res.json({ presets: PRESETS.map(p => ({ id: p.id, cargo: p.cargo, banca: p.banca, descricao: p.descricao })) });
});

// GET /presets/:id - Get specific preset
router.get('/presets/:id', (req, res) => {
    const preset = PRESETS.find(p => p.id === req.params.id);
    if (!preset) return res.status(404).json({ error: 'Preset não encontrado' });
    res.json(preset);
});

// POST /analyze - Analyze edital with AI Predictor (Tendência de Banca)
router.post('/analyze', async (req, res) => {
    let { cargo, banca, editalText, presetId } = req.body;

    if (presetId && !editalText) {
        const preset = PRESETS.find(p => p.id === presetId);
        if (preset) {
            cargo = preset.cargo;
            banca = preset.banca;
            editalText = preset.editalText;
        }
    }

    if (!editalText || !editalText.trim()) {
        return res.status(400).json({ error: 'Texto do edital ou conteúdo programático é obrigatório.' });
    }

    const targetCargo = cargo || 'Analista Tributário da Receita Federal (ATRFB)';
    const targetBanca = banca || 'FGV';

    try {
        const prompt = editalPromptTemplate(targetCargo, targetBanca, editalText);
        const analysisData = await generateJSON(prompt, editalSystemInstruction, editalSchema);

        const stmt = db.prepare('INSERT INTO edital_analyses (cargo, edital_text, analysis) VALUES (?, ?, ?)');
        const info = stmt.run(`${targetCargo} [${targetBanca}]`, editalText, JSON.stringify(analysisData));

        res.json({
            success: true,
            id: info.lastInsertRowid,
            cargo: targetCargo,
            banca: targetBanca,
            analysis: analysisData
        });
    } catch (error) {
        console.error("Edital analysis error:", error);
        res.status(500).json({ error: 'Falha ao analisar edital: ' + error.message });
    }
});

// GET / - List saved analyses
router.get('/', (req, res) => {
    try {
        const stmt = db.prepare('SELECT id, cargo, created_at FROM edital_analyses ORDER BY created_at DESC');
        res.json(stmt.all());
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// GET /:id - Get specific analysis
router.get('/:id', (req, res) => {
    try {
        const stmt = db.prepare('SELECT * FROM edital_analyses WHERE id = ?');
        const analysis = stmt.get(req.params.id);
        if (!analysis) return res.status(404).json({ error: 'Análise não encontrada' });
        
        analysis.analysis = JSON.parse(analysis.analysis);
        res.json(analysis);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
