import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import db from '../database.js';
import { generateJSON } from '../gemini.js';
import { scheduleSystemInstruction, schedulePromptTemplate, scheduleSchema } from '../prompts/schedule.js';
import { getTodayEvents } from '../calendar.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

// GET /calendar/today — Get today's scheduled study events from Google Calendar
router.get('/calendar/today', async (req, res) => {
    try {
        const url = req.query.url || process.env.GOOGLE_CALENDAR_URL;
        const result = await getTodayEvents(url);
        res.json(result);
    } catch (error) {
        console.error('Erro ao buscar eventos do calendário:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// POST /calendar/config — Save Google Calendar iCal URL
router.post('/calendar/config', async (req, res) => {
    try {
        const { url } = req.body;
        if (!url || !url.trim()) {
            return res.status(400).json({ error: 'URL é obrigatória' });
        }

        process.env.GOOGLE_CALENDAR_URL = url.trim();

        // Update in .env file
        const envPath = path.join(__dirname, '../../.env');
        if (fs.existsSync(envPath)) {
            let envContent = fs.readFileSync(envPath, 'utf8');
            if (envContent.includes('GOOGLE_CALENDAR_URL=')) {
                envContent = envContent.replace(/GOOGLE_CALENDAR_URL=.*/g, `GOOGLE_CALENDAR_URL=${url.trim()}`);
            } else {
                envContent += `\nGOOGLE_CALENDAR_URL=${url.trim()}\n`;
            }
            fs.writeFileSync(envPath, envContent, 'utf8');
        }

        // Test the URL immediately
        const testResult = await getTodayEvents(url.trim());

        res.json({ 
            success: true, 
            message: 'URL do Google Calendar salva com sucesso!',
            test: testResult
        });
    } catch (error) {
        console.error('Erro ao salvar config do calendário:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /generate
router.post('/generate', async (req, res) => {
    const { title, subjects, hoursPerDay, daysPerWeek, examDate } = req.body;

    if (!subjects || subjects.length === 0) {
        return res.status(400).json({ error: 'Subjects required' });
    }

    try {
        const prompt = schedulePromptTemplate(subjects, hoursPerDay || 4, daysPerWeek || 6, examDate);
        const data = await generateJSON(prompt, scheduleSystemInstruction, scheduleSchema);

        const config = JSON.stringify({ subjects, hoursPerDay, daysPerWeek, examDate });
        
        db.transaction(() => {
            const schedStmt = db.prepare('INSERT INTO schedules (title, config, schedule_data, exam_date) VALUES (?, ?, ?, ?)');
            const info = schedStmt.run(title || 'Meu Cronograma', config, JSON.stringify(data.schedule_data), examDate);
            const scheduleId = info.lastInsertRowid;

            const taskStmt = db.prepare('INSERT INTO schedule_tasks (schedule_id, day_of_week, subject, topic, duration_minutes) VALUES (?, ?, ?, ?, ?)');
            for (const t of data.tasks) {
                taskStmt.run(scheduleId, t.day_of_week, t.subject, t.topic, t.duration_minutes);
            }
        })();

        res.json({ success: true });
    } catch (error) {
        console.error("Schedule gen error:", error);
        res.status(500).json({ error: error.message });
    }
});

// GET / - List schedules
router.get('/', (req, res) => {
    try {
        const stmt = db.prepare('SELECT id, title, exam_date, created_at FROM schedules ORDER BY created_at DESC');
        res.json(stmt.all());
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// GET /:id - Get schedule
router.get('/:id', (req, res) => {
    try {
        const sched = db.prepare('SELECT * FROM schedules WHERE id = ?').get(req.params.id);
        if (!sched) return res.status(404).json({ error: 'Not found' });
        
        sched.config = JSON.parse(sched.config);
        sched.schedule_data = JSON.parse(sched.schedule_data);
        
        const tasks = db.prepare('SELECT * FROM schedule_tasks WHERE schedule_id = ? ORDER BY day_of_week ASC').all(req.params.id);
        
        res.json({ ...sched, tasks });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// PUT /task/:taskId
router.put('/task/:taskId', (req, res) => {
    const { completed } = req.body;
    try {
        const stmt = db.prepare('UPDATE schedule_tasks SET completed = ?, completed_at = CURRENT_TIMESTAMP WHERE id = ?');
        stmt.run(completed ? 1 : 0, req.params.taskId);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
