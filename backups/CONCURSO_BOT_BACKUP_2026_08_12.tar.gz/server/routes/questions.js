import express from 'express';
import db, { logActivity } from '../database.js';
import { generateJSON } from '../gemini.js';
import { questionsSystemInstruction, questionsPromptTemplate, questionsSchema } from '../prompts/questions.js';

const router = express.Router();

// POST /generate - Generate questions using Gemini
router.post('/generate', async (req, res) => {
    const { subject, topic, banca = 'CEBRASPE/CESPE', type = 'multiple_choice', count = 5 } = req.body;

    if (!subject) return res.status(400).json({ error: 'Subject is required' });

    try {
        const prompt = questionsPromptTemplate(subject, topic, banca, type, count);
        const generatedData = await generateJSON(prompt, questionsSystemInstruction, questionsSchema);

        const savedQuestions = [];
        const insertStmt = db.prepare(`
            INSERT INTO questions (subject, topic, banca, type, question_text, options, correct_index, explanation)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `);

        db.transaction(() => {
            for (const q of generatedData) {
                const info = insertStmt.run(
                    subject,
                    topic,
                    banca,
                    type,
                    q.question_text,
                    JSON.stringify(q.options),
                    q.correct_index,
                    q.explanation
                );
                savedQuestions.push({ id: info.lastInsertRowid, ...q });
            }
        })();

        res.json({ success: true, questions: savedQuestions });
    } catch (error) {
        console.error("Generate questions error:", error);
        res.status(500).json({ error: error.message });
    }
});

// POST /answer - Record an answer
router.post('/answer', (req, res) => {
    const { questionId, selectedAnswer } = req.body;

    if (!questionId || selectedAnswer === undefined) {
        return res.status(400).json({ error: 'Missing parameters' });
    }

    try {
        const qStmt = db.prepare('SELECT * FROM questions WHERE id = ?');
        const question = qStmt.get(questionId);

        if (!question) return res.status(404).json({ error: 'Question not found' });

        const isCorrect = question.correct_index === selectedAnswer;

        const ansStmt = db.prepare('INSERT INTO question_answers (question_id, selected_answer, is_correct) VALUES (?, ?, ?)');
        ansStmt.run(questionId, selectedAnswer, isCorrect ? 1 : 0);

        logActivity('question', `Answered question ${questionId} (${isCorrect ? 'Correct' : 'Incorrect'})`);

        res.json({
            isCorrect,
            correctIndex: question.correct_index,
            explanation: question.explanation
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// GET /stats - Aggregate stats
router.get('/stats', (req, res) => {
    try {
        const stmt = db.prepare(`
            SELECT 
                q.subject,
                COUNT(qa.id) as total_answered,
                SUM(CASE WHEN qa.is_correct = 1 THEN 1 ELSE 0 END) as total_correct
            FROM question_answers qa
            JOIN questions q ON qa.question_id = q.id
            GROUP BY q.subject
        `);
        res.json(stmt.all());
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// GET /history - Recent answered questions
router.get('/history', (req, res) => {
    try {
        const stmt = db.prepare(`
            SELECT qa.*, q.question_text, q.subject
            FROM question_answers qa
            JOIN questions q ON qa.question_id = q.id
            ORDER BY qa.answered_at DESC LIMIT 50
        `);
        res.json(stmt.all());
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
