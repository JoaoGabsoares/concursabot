# 🧠 ConcursaBot — Documentação Completa da Arquitetura, Funcionalidades e Decisões de Projeto

> **Visão Geral**: O **ConcursaBot** é uma plataforma e ecossistema inteligente de alta performance desenvolvido sob medida para preparação de concursos públicos de elite (com foco prioritário na **Receita Federal do Brasil — Analista Tributário ATRFB e Auditor AFRFB**).  
> O projeto foi idealizado como uma alternativa proprietária, local, segura e muito mais robusta ao *Concursa.ai*, integrando leitura de apostilas originais em PDF, análise preditiva de bancas examinadoras, repetição espaçada automática e sincronização com a Google Agenda.

---

## 📑 Sumário

1. [Princípios & Diretrizes do Projeto](#1-princípios--diretrizes-do-projeto)
2. [Stack Tecnológica & Arquitetura](#2-stack-tecnológica--arquitetura)
3. [Módulos do Sistema & Funcionalidades](#3-módulos-do-sistema--funcionalidades)
   - [3.1. 🎯 Tendência de Banca & Raio-X Preditivo (Engenharia Reversa Concursa.ai)](#31--tendência-de-banca--raio-x-preditivo-engenharia-reversa-concursaai)
   - [3.2. 📖 Sala de Estudos com PDF Split-Screen & Tutor IA](#32--sala-de-estudos-com-pdf-split-screen--tutor-ia)
   - [3.3. 🧠 Motor de Datas Reais & Revisões Espaçadas (Curva do Esquecimento: D+1, D+7, D+30)](#33--motor-de-datas-reais--revisões-espaçadas-curva-do-esquecimento-d1-d7-d30)
   - [3.4. 🚨 Fila de Reposição & Gestão de Matérias Atrasadas](#34--fila-de-reposição--gestão-de-matérias-atrasadas)
   - [3.5. 📅 Cronograma Semanal & Rotina Estratégica Fixa](#35--cronograma-semanal--rotina-estratégica-fixa)
   - [3.6. 🗓️ Integração Google Agenda (iCal)](#36-️-integração-google-agenda-ical)
   - [3.7. 🎯 Simulados por Banca com Fator de Penalidade](#37--simulados-por-banca-com-fator-de-penalidade)
   - [3.8. 📚 Resumos Semanais & 🃏 Flashcards de Legislação](#38--resumos-semanais--flashcards-de-legislação)
4. [🎨 Novo Design System (Light Mode Padrão & Dark Mode)](#4--novo-design-system-light-mode-padrão--dark-mode)
5. [🛠️ Histórico de Resoluções Técnicas & Decisões Críticas](#5-️-histórico-de-resoluções-técnicas--decisões-críticas)
6. [🚀 Guia de Operação & Comandos Úteis](#6--guia-de-operação--comandos-úteis)

---

## 1. Princípios & Diretrizes do Projeto

- **Privacidade & Custo Zero de Assinatura**: O sistema roda 100% no computador do usuário, armazenando histórico e materiais no banco de dados local SQLite, sem custos de mensalidades de plataformas de terceiros.
- **Fidelidade ao Material Original**: Em vez de depender apenas de resumos gerados por IA, o aluno estuda com a **apostila original do curso em PDF** (grifada pelo aluno ou do Google Drive) e a IA atua como mentora lado a lado.
- **Foco Implacável nas Bancas Reais (FGV / Cebraspe)**: Análise estatística de recorrência de artigos de lei, súmulas e histórico de pegadinhas para evitar perda de tempo com "tópicos isca" que quase nunca caem.
- **Prevenção do Esquecimento**: Se o aluno não revisa ou não resolve questões, o sistema trava o avanço e joga a aula na **Fila de Reposição**.

---

## 2. Stack Tecnológica & Arquitetura

```
┌─────────────────────────────────────────────────────────────┐
│                      FRONTEND WEB SPA                       │
│  - HTML5 Semântico + Vanilla JS (ES Modules)               │
│  - CSS3 Design System com Variáveis e Suporte a Temas       │
│  - Google Fonts: Plus Jakarta Sans (UI) & Outfit (Headings) │
│  - PDF Viewer nativo integrado                              │
└──────────────────────────────┬──────────────────────────────┘
                               │ HTTP / REST APIs
┌──────────────────────────────▼──────────────────────────────┐
│                    NODE.JS BACKEND (v22 LTS)                 │
│  - Express.js (ESM)                                         │
│  - Better-SQLite3 (com WAL mode e graceful shutdown)        │
│  - Google Gemini 2.5 Flash API (com JSON Schemas rigorosos) │
│  - Multer (upload e catalogação de PDFs)                    │
│  - node-ical (sincronização da Google Agenda)               │
└──────────────────────────────┬──────────────────────────────┘
                               │ SQL Queries / Storage
┌──────────────────────────────▼──────────────────────────────┐
│                 DATABASE & ASSETS LOCAIS                    │
│  - SQLite (data/concurso.db)                                │
│  - Uploads de Apostilas (uploads/*.pdf)                     │
│  - Migrations automáticas na inicialização                  │
└─────────────────────────────────────────────────────────────┘
```

### Versão Obrigatória do Runtime:
- **Node.js**: `v22.23.2 LTS` (Fixado via arquivo `.nvmrc` para garantir compatibilidade com binários C++ do SQLite).

---

## 3. Módulos do Sistema & Funcionalidades

### 3.1. 🎯 Tendência de Banca & Raio-X Preditivo (Engenharia Reversa Concursa.ai)
Módulo construído a partir do estudo das funcionalidades de plataformas como *Concursa.ai*, adaptado com foco cirúrgico na banca **FGV (Fundação Getulio Vargas)** e **Cebraspe**.

- **Modelos Prontos de 1 Clique**:
  - 🏛️ *Receita Federal — Analista Tributário (ATRFB) • FGV* (Wave 1 e Wave 2 completas).
  - 🏛️ *Receita Federal — Auditor Fiscal (AFRFB) • FGV*.
  - 🚔 *Polícia Federal — Agente • Cebraspe*.
  - ✏️ *Modo Personalizado*: Campo para colar qualquer edital e selecionar a banca (FGV, Cebraspe, FCC, Cesgranrio, Vunesp).
- **DNA do Examinador & Proporção Real de Cobrança**:
  - Barra visual proporcional dividida em:
    - 🟦 **% Letra da Lei** (Artigos de lei e texto seco)
    - 🟩 **% Jurisprudência & Súmulas** (Decisões STF/STJ)
    - 🟨 **% Casos Práticos / Historinhas** (Estilo característico da FGV com nomes fictícios)
    - 🟪 **% Doutrina Teórica**
  - Card dedicado a **⚠️ Armadilhas & Pegadinhas Clássicas da Banca**.
- **Classificação Estatística dos Tópicos**:
  - 🔥 **SEMPRE CAI (Alta Incidência > 75%)**: Tópicos com alta probabilidade de prova, justificativa estratégica e **Tags com os Artigos de Lei e Súmulas Obrigatórias**.
  - 📈 **TENDÊNCIAS RECENTES (2024-2026)**: Inovações legislativas (ex: Reforma Tributária EC 132/23, novas leis complementares) que começaram a ser cobradas com força.
  - ⚠️ **INCIDÊNCIA MÉDIA (30% a 70%)**: Assuntos com frequência moderada.
  - 🧊 **TÓPICOS ISCA / RARAMENTE COBRADOS (< 15%)**: Assuntos extensos que a banca raramente cobra (baixo custo-benefício).
- **Ações Rápidas Integradas**:
  - `[⚡ Aplicar no Cronograma]` → Transfere o planejamento da matéria para a grade semanal.
  - `[🎯 Simulado da Tendência]` → Gera bateria de questões com base no DNA da banca.
  - `[📖 Estudar Matéria]` → Abre a Sala de Estudos com a apostila correspondente.

---

### 3.2. 📖 Sala de Estudos com PDF Split-Screen, Raio-X da Banca & Tutor IA
- **Visualizador Dividido (Split Screen)**:
  - **Lado Esquerdo**: 
    - 📄 *Apostila Original em PDF* (leitor nativo).
    - 🎯 *Aba Raio-X & Foco FGV (Smart Filter)*:
      - 🧭 **Roteiro Estratégico de Leitura** (orienta por onde começar e onde focar no PDF).
      - 🔥 **O que Sempre Cai na FGV nesta Aula (>75%)**.
      - 🧊 **Tópicos Isca da Aula (<15%)** (seções para ler rápido ou pular).
      - ⚖️ **Artigos de Lei & Súmulas Obrigatórias para Grifar no PDF**.
    - 📋 *Resumo Estratégico da Aula*.
  - **Lado Direito**: Tutor IA interativo contextualizado na matéria para tirar dúvidas em tempo real.
- **Cronômetro de Estudo Pomodoro / Foco**:
  - Seleção de sessões de 25 min, 45 min, 60 min, 90 min ou 120 min com barra de progresso visual.
- **Questões Imediatas de Fixação**:
  - Calibradas no DNA da banca ao término da leitura para consolidar a matéria na memória de longo prazo.

---

### 3.3. 🧠 Motor de Datas Reais & Revisões Espaçadas (Curva do Esquecimento: D+1, D+7, D+30)
- **Designação de Data de Estudo**:
  - No momento do upload ou via botão **`📅 Data`** no catálogo, o aluno pode informar exatamente quando estudou (ou quando pretende estudar) a aula:
    - `[⏮️ Segunda passada (10/08)]`
    - `[⏮️ Ontem (11/08)]`
    - `[⭐ Hoje (12/08)]`
    - `[📅 Outra Data Customizada]`
- **Cálculo Automático da Curva do Esquecimento**:
  - Ao registrar que uma matéria foi estudada no dia **D** (ex: `10/08`), o motor gera automaticamente:
    - **Revisão D+1 (24 Horas)**: Data `11/08` (se a data atual for posterior, o sistema marca como **`ATRASADA`**).
    - **Revisão D+7 (7 Dias)**: Data `17/08` (próxima segunda-feira).
    - **Revisão D+30 (30 Dias)**: Data `09/09`.
- **Baixa e Reagendamento**:
  - No Dashboard e na Sala de Estudos, cada revisão possui os botões **`[▶️ Revisar Aula]`** e **`[✅ Revisado]`**.

---

### 3.4. 🚨 Fila de Reposição & Gestão de Matérias Atrasadas
Central unificada no topo do Dashboard para garantir que nenhum conteúdo fique esquecido:
1. **Revisões Espaçadas Atrasadas** (destaque em vermelho com aviso do dia que venceu).
2. **Revisões do Dia Atual** (destaque em azul).
3. **Estudos Adiados / Matérias Não Concluídas** (ex: estudo da manhã adiado para a noite).
4. **Apostilas Lidas sem Questões de Fixação** (alerta para resolver os exercícios da aula).

---

### 3.5. 📅 Cronograma Semanal & Rotina Estratégica Fixa
Ajustado para seguir a rotina de um aprovado em concursos fiscais:
- **Segunda a Quinta**: Ciclos de teoria nas apostilas + resolução imediata de questões de fixação nas matérias prioritárias.
- **Sexta-feira à noite**: ✍️ **Treinamento de Redação / Questão Discursiva (Estilo FGV)** — estudo de casos práticos e pareceres da Receita Federal.
- **Sábado**: 📚 **Resumo Semanal Integrado & Mapa Mental** — 1 vez por semana para consolidar todo o conteúdo estudado de Segunda a Sexta.
- **Domingo**: 🎯 **Simulados Gerais da Banca FGV** e Descanso Estratégico.

---

### 3.6. 🗓️ Integração Google Agenda (iCal)
- Permite colar o endereço secreto iCal da Google Agenda (`.ics`).
- O sistema faz o parsing em tempo real dos blocos agendados para o dia e exibe na dashboard com link direto para iniciar o estudo da respectiva disciplina.

---

### 3.7. 🎯 Simulados por Banca com Fator de Penalidade
- Simulação fiel de provas:
  - **FGV**: Múltipla escolha (A, B, C, D, E) com historinhas e casos práticos.
  - **Cebraspe**: Certo / Errado com **fator negativo (-1 para cada erro)** e opção de "Deixar em Branco".
- Cronômetro de tempo de prova com alerta e cálculo automático da nota líquida final.

---

### 3.8. 📚 Resumos Semanais & 🃏 Flashcards de Legislação
- **Resumos**: Geração de resumos em tópicos e mapas mentais em formato Mermaid.js para consolidação aos sábados.
- **Flashcards**: Sistema de repetição espaçada ativa (Fácil, Médio, Difícil) para memorização de números de artigos de lei, prazos e jurisprudência pacificada.

---

## 4. 🎨 Novo Design System (Light Mode Padrão & Dark Mode)

Para fugir dos temas "escuros genéricos de IA" que cansam a vista após minutos de leitura, o ConcursaBot foi reconstruído com um **Design System Editorial de Alto Padrão**:

| Elemento | Modo Claro (Padrão) | Modo Escuro (Dark) |
| :--- | :--- | :--- |
| **Fundo Geral** | `#F8FAFC` (Off-white / Slate 50) | `#0B0F19` (Deep Slate) |
| **Superfície dos Cards** | `#FFFFFF` (Branco Puro com sombra suave) | `#131C2E` / `#1E293B` |
| **Bordas** | `#E2E8F0` (Linhas ultra-finas e limpas) | `rgba(255, 255, 255, 0.08)` |
| **Tipografia Principal** | `#0F172A` (Slate 900 — Contraste máximo) | `#F8FAFC` (Slate 50) |
| **Tipografia Secundária** | `#475569` (Slate 600) | `#94A3B8` (Slate 400) |
| **Família da UI** | **Plus Jakarta Sans** (Moderna, nítida e ergonômica) | **Plus Jakarta Sans** |
| **Família dos Títulos** | **Outfit** (Robusta, elegante e com peso visual) | **Outfit** |
| **Alternador de Tema** | Botão `☀️ / 🌙` no cabeçalho com persistência em `localStorage` | Botão `☀️ / 🌙` no cabeçalho |

---

## 5. 🛠️ Histórico de Resoluções Técnicas & Decisões Críticas

### 1. Incompatibilidade Node.js 24 vs Better-SQLite3
- **Problema**: O Node 24 gerava falha de asserção do V8 (`RemoveEnvironmentCleanupHook(v8::Isolate*, CleanupHook, void*) at ../src/api/hooks.cc:142 - Assertion failed: (env) != nullptr`) e ABI mismatch 127 vs 137 ao finalizar o processo do SQLite.
- **Solução**: 
  - Fixação do projeto no **Node.js v22.23.2 LTS** via `.nvmrc` e `engines` no `package.json`.
  - Recompilação dos binários nativos C++ do `better-sqlite3`.
  - Inclusão de handlers de graceful shutdown (`SIGINT`, `SIGTERM`) fechando as conexões do banco de forma segura.

### 2. Foreign Key de Materiais e Sessões
- **Problema**: A criação de sessões de estudo (`study_sessions`) falhava caso `material_id` fosse referenciado como texto em vez de chave estrangeira numérica correspondente à tabela `study_materials`.
- **Solução**: Migração do schema com constraints de integridade referencial e fallbacks quando uma sessão é criada a partir de tema genérico.

### 3. Sincronização de Datas e Fuso Horário
- **Problema**: Diferenças de UTC ao calcular prazos de D+1, D+7 e D+30 poderiam adiantar ou atrasar datas em fusos brasileiros (UTC-3).
- **Solução**: Utilização de formato padrão `YYYY-MM-DD` nas queries SQLite e funções de formatação `formatDate` compatíveis com o fuso local do navegador.

---

## 6. 🚀 Guia de Operação & Comandos Úteis

### Como iniciar o ConcursaBot:
```bash
cd "/home/joao/Área de trabalho/CONCURSO_BOT"

# Garantir o uso do Node 22 LTS
export PATH="/home/joao/.nvm/versions/node/v22.23.2/bin:$PATH"

# Iniciar o servidor
npm start
```
O servidor estará acessível em: **`http://localhost:3000`**.

### Principais Atalhos e Rotas:
- **`#dashboard`**: Painel Geral, Fila de Reposição e Revisões Espaçadas do Dia.
- **`#study-room`**: Sala de Estudos com Leitor PDF e Tutor IA.
- **`#schedule`**: Planejador Semanal com Sexta (Redação) e Sábado (Resumo).
- **`#edital`**: Tendência de Banca & Raio-X Preditivo (FGV / Cebraspe).
- **`#simulados`**: Simulados com Tempo e Fator Negativo Cebraspe.
- **`#questions`**: Banco e Gerador de Questões.
- **`#summaries`**: Resumos e Mapas Mentais.
- **`#flashcards`**: Flashcards de Fixação Ativa.
- **`#tutor`**: Chat com Tutor Especialista 24/7.
- **`#rag`**: Pesquisa Semântica em todo o Acervo de Apostilas.

---

*Documentação atualizada em 12/08/2026.* 🎯📚
