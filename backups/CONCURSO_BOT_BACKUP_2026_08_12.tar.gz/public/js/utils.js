export function parseMarkdown(text) {
  if (!text) return '';
  
  let html = text;
  
  // Headers
  html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
  html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
  html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');
  
  // Bold & Italic
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
  
  // Code Blocks
  html = html.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
  html = html.replace(/`(.*?)`/g, '<code>$1</code>');
  
  // Blockquotes
  html = html.replace(/^\> (.*$)/gim, '<blockquote>$1</blockquote>');
  
  // Lists
  html = html.replace(/^\s*\n\*/gm, '<ul>\n*');
  html = html.replace(/^(\*|\-) (.*)$/gim, '<li>$2</li>');
  html = html.replace(/<\/li>\n<ul>/gim, '<ul>');
  html = html.replace(/<\/li>\n<li>/gim, '</li><li>');
  // List wrapper
  html = html.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');

  // Paragraphs
  html = html.split('\n\n').map(p => {
    if (p.startsWith('<h') || p.startsWith('<ul') || p.startsWith('<pre') || p.startsWith('<block')) return p;
    return `<p>${p}</p>`;
  }).join('');
  
  return `<div class="markdown-content">${html}</div>`;
}

export const renderMarkdown = parseMarkdown;

export function formatDate(dateString) {
  if (!dateString) return '';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return String(dateString);
  return date.toLocaleDateString('pt-BR');
}

export function generateId() {
  return Math.random().toString(36).substring(2, 9);
}

export function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;
  
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerText = message;
  
  container.appendChild(toast);
  
  setTimeout(() => {
    toast.style.animation = 'slideIn 0.3s reverse backwards';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

export function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

export function getSubjectColor(subject) {
  if (!subject) return 'secondary';
  const s = String(subject).toLowerCase();
  if (s.includes('tribut')) return 'warning';
  if (s.includes('constituc')) return 'primary';
  if (s.includes('administra')) return 'danger';
  if (s.includes('previdenc')) return 'success';
  if (s.includes('portug')) return 'info';
  if (s.includes('dado') || s.includes('ti') || s.includes('inform')) return 'primary';
  if (s.includes('aduan')) return 'warning';
  if (s.includes('logic') || s.includes('rlm')) return 'info';
  if (s.includes('contab')) return 'success';
  if (s.includes('ingles')) return 'secondary';
  return 'secondary';
}
