import { api } from './api.js';
import { showToast, formatDate, getSubjectColor } from './utils.js';

let currentSchedule = null;

export async function render(container) {
  container.innerHTML = `
    <div class="schedule-module">
      <!-- Google Calendar Sync Card -->
      <div class="card slide-up" style="margin-bottom: 1.5rem; border-left: 4px solid #60A5FA;">
        <div class="card-header" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem;">
          <div>
            <h3 style="margin:0; color:#60A5FA;">📅 Integração com Google Agenda</h3>
            <p class="text-muted" style="font-size:0.85rem; margin-top:0.25rem;">
              Puxe automaticamente os blocos e matérias que você agendou para hoje.
            </p>
          </div>
          <button class="btn btn-secondary btn-sm" id="btn-refresh-gcal">🔄 Atualizar</button>
        </div>

        <div style="margin-top:1rem;">
          <div class="form-group">
            <label for="gcal-url" style="font-weight:600;">Endereço Secreto iCal da sua Google Agenda (.ics):</label>
            <div style="display:flex; gap:0.5rem; flex-wrap:wrap;">
              <input type="url" id="gcal-url" class="form-control" style="flex:1; min-width:280px;" placeholder="https://calendar.google.com/calendar/ical/seuemail%40gmail.com/private-xxxx/basic.ics">
              <button class="btn btn-primary" id="btn-save-gcal">Salvar e Conectar</button>
            </div>
            <p class="text-muted" style="font-size:0.75rem; margin-top:0.35rem;">
              💡 <strong>Como pegar:</strong> No Google Agenda no computador, clique em "Configurações da agenda" → role até "Integrar agenda" → copie o link em <strong>"Endereço secreto no formato iCal"</strong>.
            </p>
          </div>

          <div id="gcal-status-box" style="margin-top:1rem;"></div>
        </div>
      </div>

      <!-- Schedule Generator & Weekly View -->
      <div class="grid-2 slide-up">
        <!-- Left: Generator Form -->
        <div class="card">
          <h3 style="color:var(--color-schedule); margin-bottom: 1.25rem;">🤖 Gerador IA de Cronograma (Receita Federal)</h3>
          
          <div class="form-group">
            <label for="sch-title" style="font-weight:600;">Título do Cronograma</label>
            <input type="text" id="sch-title" class="form-control" value="Plano de Estudos ATRFB — Pré-Edital">
          </div>

          <div class="grid-2">
            <div class="form-group">
              <label for="sch-hours" style="font-weight:600;">Horas / Dia</label>
              <input type="number" id="sch-hours" class="form-control" value="4" min="1" max="12">
            </div>
            <div class="form-group">
              <label for="sch-date" style="font-weight:600;">Data Estimada da Prova</label>
              <input type="date" id="sch-date" class="form-control" value="2027-01-04">
            </div>
          </div>

          <div class="form-group">
            <label style="font-weight:600;">Dias Disponíveis na Semana</label>
            <div style="display:flex; gap:0.4rem; margin-top:0.3rem; flex-wrap:wrap;">
              <label style="background:var(--bg-tertiary); padding:0.4rem 0.6rem; border-radius:4px; font-size:0.85rem; cursor:pointer;"><input type="checkbox" name="sch-day" value="1" checked> Seg</label>
              <label style="background:var(--bg-tertiary); padding:0.4rem 0.6rem; border-radius:4px; font-size:0.85rem; cursor:pointer;"><input type="checkbox" name="sch-day" value="2" checked> Ter</label>
              <label style="background:var(--bg-tertiary); padding:0.4rem 0.6rem; border-radius:4px; font-size:0.85rem; cursor:pointer;"><input type="checkbox" name="sch-day" value="3" checked> Qua</label>
              <label style="background:var(--bg-tertiary); padding:0.4rem 0.6rem; border-radius:4px; font-size:0.85rem; cursor:pointer;"><input type="checkbox" name="sch-day" value="4" checked> Qui</label>
              <label style="background:var(--bg-tertiary); padding:0.4rem 0.6rem; border-radius:4px; font-size:0.85rem; cursor:pointer;"><input type="checkbox" name="sch-day" value="5" checked> Sex</label>
              <label style="background:var(--bg-tertiary); padding:0.4rem 0.6rem; border-radius:4px; font-size:0.85rem; cursor:pointer;"><input type="checkbox" name="sch-day" value="6" checked> Sáb</label>
              <label style="background:var(--bg-tertiary); padding:0.4rem 0.6rem; border-radius:4px; font-size:0.85rem; cursor:pointer;"><input type="checkbox" name="sch-day" value="7"> Dom</label>
            </div>
          </div>

          <!-- Disciplinas do Ciclo (Structured & Organized) -->
          <div class="form-group" style="margin-top:1rem;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.4rem; flex-wrap:wrap; gap:0.4rem;">
              <label style="font-weight:700; margin:0;">📚 Disciplinas do Ciclo de Estudos</label>
              <div class="schedule-quick-btns" style="margin:0;">
                <button type="button" class="schedule-quick-btn" id="btn-select-wave1">⚡ Apenas Wave 1</button>
                <button type="button" class="schedule-quick-btn" id="btn-select-all-subjects">Selecionar Todas</button>
                <button type="button" class="schedule-quick-btn" id="btn-clear-subjects">Limpar</button>
              </div>
            </div>

            <!-- Wave 1: Alta Prioridade -->
            <div class="schedule-subject-section">
              <div class="schedule-section-header">
                <span class="schedule-section-title" style="color:#60A5FA;">
                  🔥 Wave 1 — Alta Prioridade de Pontos (104 questões)
                </span>
              </div>
              <div class="schedule-subject-grid">
                <label class="schedule-subject-card is-selected">
                  <input type="checkbox" name="sch-subject" value="Direito Tributário" data-wave="1" checked>
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Direito Tributário</span>
                    <span class="schedule-subject-weight">16 questões • Teoria e CTN</span>
                  </div>
                </label>

                <label class="schedule-subject-card is-selected">
                  <input type="checkbox" name="sch-subject" value="Direito Previdenciário" data-wave="1" checked>
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Direito Previdenciário</span>
                    <span class="schedule-subject-weight">16 questões • Custeio e Benefícios</span>
                  </div>
                </label>

                <label class="schedule-subject-card is-selected">
                  <input type="checkbox" name="sch-subject" value="Língua Portuguesa" data-wave="1" checked>
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Língua Portuguesa</span>
                    <span class="schedule-subject-weight">15 questões • Sintaxe e FGV</span>
                  </div>
                </label>

                <label class="schedule-subject-card is-selected">
                  <input type="checkbox" name="sch-subject" value="Fluência de Dados" data-wave="1" checked>
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Fluência de Dados</span>
                    <span class="schedule-subject-weight">15 questões • SQL e Dados</span>
                  </div>
                </label>

                <label class="schedule-subject-card is-selected">
                  <input type="checkbox" name="sch-subject" value="Direito Constitucional" data-wave="1" checked>
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Direito Constitucional</span>
                    <span class="schedule-subject-weight">14 questões • Direitos e Poderes</span>
                  </div>
                </label>

                <label class="schedule-subject-card is-selected">
                  <input type="checkbox" name="sch-subject" value="Legislação Tributária" data-wave="1" checked>
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Legislação Tributária</span>
                    <span class="schedule-subject-weight">14 questões • IRPJ, PIS e COFINS</span>
                  </div>
                </label>

                <label class="schedule-subject-card is-selected">
                  <input type="checkbox" name="sch-subject" value="Legislação Aduaneira" data-wave="1" checked>
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Legislação Aduaneira</span>
                    <span class="schedule-subject-weight">14 questões • Aduana e Comex</span>
                  </div>
                </label>
              </div>
            </div>

            <!-- Wave 2: Fila Complementar -->
            <div class="schedule-subject-section" style="margin-top:0.6rem;">
              <div class="schedule-section-header">
                <span class="schedule-section-title" style="color:#F59E0B;">
                  ⏳ Wave 2 — Fila Complementar (36 questões)
                </span>
              </div>
              <div class="schedule-subject-grid">
                <label class="schedule-subject-card">
                  <input type="checkbox" name="sch-subject" value="Direito Administrativo" data-wave="2">
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Direito Administrativo</span>
                    <span class="schedule-subject-weight">12 questões • Atos e Licitações</span>
                  </div>
                </label>

                <label class="schedule-subject-card">
                  <input type="checkbox" name="sch-subject" value="Raciocínio Lógico Matemático" data-wave="2">
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Raciocínio Lógico</span>
                    <span class="schedule-subject-weight">10 questões • Lógica e Probabilidade</span>
                  </div>
                </label>

                <label class="schedule-subject-card">
                  <input type="checkbox" name="sch-subject" value="Contabilidade Geral" data-wave="2">
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Contabilidade Geral</span>
                    <span class="schedule-subject-weight">10 questões • CPC e Balanço</span>
                  </div>
                </label>

                <label class="schedule-subject-card">
                  <input type="checkbox" name="sch-subject" value="Estatística" data-wave="2">
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Estatística</span>
                    <span class="schedule-subject-weight">10 questões • Descritiva e Inferencial</span>
                  </div>
                </label>

                <label class="schedule-subject-card">
                  <input type="checkbox" name="sch-subject" value="Administração Geral e Pública" data-wave="2">
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Administração Pública</span>
                    <span class="schedule-subject-weight">10 questões • Gestão e Governança</span>
                  </div>
                </label>

                <label class="schedule-subject-card">
                  <input type="checkbox" name="sch-subject" value="Língua Inglesa" data-wave="2">
                  <div class="schedule-subject-info">
                    <span class="schedule-subject-name">Língua Inglesa</span>
                    <span class="schedule-subject-weight">10 questões • Interpretação Técnica</span>
                  </div>
                </label>
              </div>
            </div>
          </div>

          <button id="btn-gen-schedule" class="btn btn-primary" style="width:100%; margin-top:1.25rem; padding:0.9rem; background:var(--gradient-primary); font-size:1rem; font-weight:600;">
            <span class="btn-text">⚡ Gerar Cronograma Inteligente</span>
            <span class="btn-loading" style="display:none;">⏳ Calculando distribuição de disciplinas...</span>
          </button>
        </div>
        
        <!-- Right: Current Schedule & Weekly Tasks -->
        <div class="card">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem; flex-wrap:wrap; gap:0.5rem;">
            <h3 id="schedule-display-title">📅 Sua Distribuição Semanal</h3>
            <span id="schedule-progress-badge" class="badge badge-primary">Carregando...</span>
          </div>

          <div id="week-view" style="display:flex; flex-direction:column; gap:0.75rem; max-height:600px; overflow-y:auto; padding-right:0.25rem;">
            <div class="loading-placeholder">Carregando cronograma ativo...</div>
          </div>
        </div>
      </div>
    </div>
  `;

  setupCalendarHandlers();
  setupSubjectPickerEvents();
  setupScheduleGeneratorHandlers();
  loadCurrentSchedule();
}

// ============================================================
// SUBJECT PICKER QUICK ACTIONS & TOGGLES
// ============================================================

function setupSubjectPickerEvents() {
  const cards = document.querySelectorAll('.schedule-subject-card');

  cards.forEach(card => {
    const chk = card.querySelector('input[type="checkbox"]');
    chk.addEventListener('change', () => {
      if (chk.checked) card.classList.add('is-selected');
      else card.classList.remove('is-selected');
    });
  });

  document.getElementById('btn-select-wave1')?.addEventListener('click', () => {
    cards.forEach(card => {
      const chk = card.querySelector('input[type="checkbox"]');
      const isWave1 = chk.dataset.wave === '1';
      chk.checked = isWave1;
      if (isWave1) card.classList.add('is-selected');
      else card.classList.remove('is-selected');
    });
    showToast('Selecionadas as 7 disciplinas da Wave 1 (Recomendado ATRFB)', 'info');
  });

  document.getElementById('btn-select-all-subjects')?.addEventListener('click', () => {
    cards.forEach(card => {
      const chk = card.querySelector('input[type="checkbox"]');
      chk.checked = true;
      card.classList.add('is-selected');
    });
  });

  document.getElementById('btn-clear-subjects')?.addEventListener('click', () => {
    cards.forEach(card => {
      const chk = card.querySelector('input[type="checkbox"]');
      chk.checked = false;
      card.classList.remove('is-selected');
    });
  });
}

// ============================================================
// SCHEDULE GENERATOR HANDLER
// ============================================================

function setupScheduleGeneratorHandlers() {
  const btn = document.getElementById('btn-gen-schedule');
  if (!btn) return;

  btn.addEventListener('click', async () => {
    const title = document.getElementById('sch-title').value.trim() || 'Cronograma ATRFB';
    const hoursPerDay = parseInt(document.getElementById('sch-hours').value, 10) || 4;
    const examDate = document.getElementById('sch-date').value || null;

    const subjectBoxes = Array.from(document.querySelectorAll('input[name="sch-subject"]:checked'));
    const subjects = subjectBoxes.map(cb => cb.value);

    const dayBoxes = Array.from(document.querySelectorAll('input[name="sch-day"]:checked'));
    const daysPerWeek = dayBoxes.length || 6;

    if (subjects.length === 0) {
      showToast('Selecione pelo menos uma disciplina.', 'warning');
      return;
    }

    const btnText = btn.querySelector('.btn-text');
    const btnLoading = btn.querySelector('.btn-loading');

    btn.disabled = true;
    btnText.style.display = 'none';
    btnLoading.style.display = 'inline';

    showToast('🤖 A IA está organizando o ciclo ótimo de estudo...', 'info');

    try {
      const res = await fetch('/api/schedule/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          subjects,
          hoursPerDay,
          daysPerWeek,
          examDate
        })
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Falha ao gerar cronograma');
      }

      showToast('🎉 Cronograma semanal gerado com sucesso!', 'success');
      loadCurrentSchedule();

    } catch (error) {
      console.error('Schedule gen error:', error);
      showToast(error.message || 'Erro ao gerar cronograma.', 'error');
    } finally {
      btn.disabled = false;
      btnText.style.display = 'inline';
      btnLoading.style.display = 'none';
    }
  });
}

// ============================================================
// LOAD & RENDER SCHEDULE
// ============================================================

async function loadCurrentSchedule() {
  const container = document.getElementById('week-view');
  const titleEl = document.getElementById('schedule-display-title');
  const badgeEl = document.getElementById('schedule-progress-badge');

  try {
    const res = await fetch('/api/schedule');
    if (!res.ok) throw new Error('Falha ao listar cronogramas');

    const schedules = await res.json();

    if (schedules.length === 0) {
      badgeEl.textContent = 'Sem cronograma';
      badgeEl.className = 'badge badge-secondary';
      container.innerHTML = `
        <div class="empty-state" style="padding:2rem;">
          <span class="empty-icon">📅</span>
          <h4>Nenhum cronograma ativo</h4>
          <p class="text-muted" style="font-size:0.85rem;">Selecione as matérias ao lado e clique em "Gerar Cronograma Inteligente".</p>
        </div>
      `;
      return;
    }

    const latestId = schedules[0].id;
    const detailRes = await fetch(`/api/schedule/${latestId}`);
    currentSchedule = await detailRes.json();

    titleEl.textContent = `📅 ${currentSchedule.title || 'Cronograma Semanal'}`;

    const tasks = currentSchedule.tasks || [];
    const completedTasks = tasks.filter(t => t.completed).length;
    const pct = tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0;

    badgeEl.textContent = `${completedTasks}/${tasks.length} concluídas (${pct}%)`;
    badgeEl.className = pct === 100 ? 'badge badge-success' : 'badge badge-primary';

    // Group tasks by day of week (1 to 7)
    const dayNames = {
      1: 'Segunda-feira',
      2: 'Terça-feira',
      3: 'Quarta-feira',
      4: 'Quinta-feira',
      5: 'Sexta-feira',
      6: 'Sábado',
      7: 'Domingo'
    };

    const tasksByDay = {};
    for (let d = 1; d <= 7; d++) tasksByDay[d] = [];

    tasks.forEach(t => {
      const d = t.day_of_week || 1;
      if (!tasksByDay[d]) tasksByDay[d] = [];
      tasksByDay[d].push(t);
    });

    let html = '';

    for (let d = 1; d <= 7; d++) {
      const dayTasks = tasksByDay[d];
      if (dayTasks.length === 0) continue;

      html += `
        <div style="display:flex; flex-direction:column; gap:0.4rem; margin-bottom:0.75rem;">
          <h5 style="color:var(--text-muted); text-transform:uppercase; font-size:0.8rem; letter-spacing:0.5px; margin:0 0 0.2rem 0;">
            ${dayNames[d] || 'Dia ' + d}
          </h5>
          ${dayTasks.map(t => {
            const subjectColor = getSubjectColor(t.subject);
            const isDone = !!t.completed;

            return `
              <div style="background:var(--bg-tertiary); border-left:4px solid var(--color-tutor); padding:0.75rem 1rem; border-radius:var(--radius-sm); display:flex; justify-content:space-between; align-items:center; gap:0.5rem; transition:all 0.2s; ${isDone ? 'opacity:0.6; text-decoration:line-through;' : ''}">
                <div style="flex:1;">
                  <div style="display:flex; align-items:center; gap:0.5rem; flex-wrap:wrap;">
                    <span class="badge badge-${subjectColor}">${t.subject}</span>
                    <strong style="font-size:0.9rem;">${t.topic}</strong>
                  </div>
                  <p style="font-size:0.75rem; color:var(--text-muted); margin:0.2rem 0 0 0;">
                    ⏱️ Duração: ${t.duration_minutes} min
                  </p>
                </div>

                <div style="display:flex; align-items:center; gap:0.5rem;">
                  <button class="btn btn-primary btn-sm" onclick="window.location.hash='#study-room'" title="Abrir na Sala de Estudos">
                    ▶️
                  </button>
                  <input type="checkbox" class="task-checkbox" data-id="${t.id}" ${isDone ? 'checked' : ''} style="width:20px; height:20px; cursor:pointer;" title="Marcar como concluída">
                </div>
              </div>
            `;
          }).join('')}
        </div>
      `;
    }

    container.innerHTML = html;

    // Task completion handler
    container.querySelectorAll('.task-checkbox').forEach(chk => {
      chk.addEventListener('change', async () => {
        const taskId = chk.dataset.id;
        const completed = chk.checked;

        try {
          await fetch(`/api/schedule/task/${taskId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ completed })
          });

          showToast(completed ? 'Tarefa concluída! 👏' : 'Tarefa desmarcada.', 'info');
          loadCurrentSchedule();
        } catch (e) {
          showToast('Erro ao atualizar tarefa.', 'error');
        }
      });
    });

  } catch (error) {
    console.error('Load schedule error:', error);
    container.innerHTML = `<p class="text-muted" style="font-size:0.85rem;">Não foi possível carregar o cronograma.</p>`;
  }
}

// ============================================================
// GOOGLE CALENDAR SYNC
// ============================================================

function setupCalendarHandlers() {
  const saveBtn = document.getElementById('btn-save-gcal');
  const refreshBtn = document.getElementById('btn-refresh-gcal');
  const urlInput = document.getElementById('gcal-url');

  saveBtn.addEventListener('click', async () => {
    const url = urlInput.value.trim();
    if (!url) {
      showToast('Insira a URL do seu calendário Google.', 'warning');
      return;
    }

    try {
      const res = await fetch('/api/schedule/calendar/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });

      const data = await res.json();
      if (data.success) {
        showToast('Google Agenda conectada!', 'success');
        renderCalendarStatus(data.test);
      } else {
        showToast(data.error || 'Erro ao conectar.', 'error');
      }
    } catch (e) {
      showToast('Erro ao salvar URL do calendário.', 'error');
    }
  });

  refreshBtn.addEventListener('click', checkCurrentCalendar);
  checkCurrentCalendar();
}

async function checkCurrentCalendar() {
  const statusBox = document.getElementById('gcal-status-box');
  if (!statusBox) return;

  try {
    const res = await fetch('/api/schedule/calendar/today');
    const data = await res.json();
    renderCalendarStatus(data);
  } catch (e) {
    statusBox.innerHTML = `<p class="text-muted" style="font-size:0.85rem;">Google Agenda não conectada.</p>`;
  }
}

function renderCalendarStatus(data) {
  const statusBox = document.getElementById('gcal-status-box');
  if (!statusBox) return;

  if (!data || !data.success) {
    statusBox.innerHTML = `
      <div style="padding:0.75rem 1rem; background:rgba(245, 158, 11, 0.1); border-left:3px solid #F59E0B; border-radius:4px; font-size:0.85rem;">
        ${data?.error || 'Insira o Endereço Secreto iCal (.ics) para sincronizar seus eventos de hoje.'}
      </div>
    `;
    return;
  }

  if (!data.events || data.events.length === 0) {
    statusBox.innerHTML = `
      <div style="padding:0.75rem 1rem; background:rgba(16, 185, 129, 0.1); border-left:3px solid #10B981; border-radius:4px; font-size:0.85rem;">
        ✅ <strong>Google Agenda conectada com sucesso!</strong> Nenhum evento de estudo marcado para a data de hoje.
      </div>
    `;
    return;
  }

  statusBox.innerHTML = `
    <div style="padding:0.75rem 1rem; background:rgba(16, 185, 129, 0.1); border-left:3px solid #10B981; border-radius:4px; font-size:0.85rem;">
      ✅ <strong>Google Agenda Conectada!</strong> ${data.events.length} evento(s) encontrado(s) para hoje:
      <ul style="margin:0.5rem 0 0 1rem;">
        ${data.events.map(ev => `
          <li><strong>${ev.timeDisplay}:</strong> ${ev.summary} ${ev.subject ? `<span class="badge badge-info">${ev.subject}</span>` : ''}</li>
        `).join('')}
      </ul>
    </div>
  `;
}
