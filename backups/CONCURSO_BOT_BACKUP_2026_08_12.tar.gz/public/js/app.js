import { showToast } from './utils.js';

// Route Definitions mapping hash to module filename and page info
const routes = {
  'dashboard': { file: 'dashboard.js', title: 'Dashboard', subtitle: 'Visão geral do seu progresso e fila de estudos' },
  'tutor': { file: 'tutor.js', title: 'Tutor IA 24/7', subtitle: 'Tire suas dúvidas conceituais e de jurisprudência em tempo real' },
  'questions': { file: 'questions.js', title: 'Banco de Questões', subtitle: 'Geração e resolução inteligente de questões por banca' },
  'simulados': { file: 'simulados.js', title: 'Simulados por Banca', subtitle: 'Treinamento focado no estilo e tempo real da prova' },
  'summaries': { file: 'summaries.js', title: 'Resumos Semanais', subtitle: 'Consolidação semanal aos sábados e mapas mentais' },
  'edital': { file: 'edital.js', title: 'Tendência de Banca & Raio-X Preditivo', subtitle: 'Descubra o que sempre cai, o que nunca cai e as tendências 2024-2026' },
  'flashcards': { file: 'flashcards.js', title: 'Flashcards de Fixação', subtitle: 'Repetição espaçada ativa para memorização de leis e súmulas' },
  'schedule': { file: 'schedule.js', title: 'Cronograma Semanal', subtitle: 'Planejamento com Sexta: Redação e Sábado: Resumo Semanal' },
  'study-room': { file: 'study-room.js', title: 'Sala de Estudos', subtitle: 'Estude com a apostila original (PDF) e fixe com questões imediatas' },
  'rag': { file: 'rag.js', title: 'Acervo Drive / RAG (1.000 PDFs)', subtitle: 'Pesquisa semântica e respostas com citações de todo o seu acervo' }
};

// ============================================================
// THEME MANAGER (LIGHT MODE DEFAULT & DARK MODE)
// ============================================================

function initTheme() {
  const savedTheme = localStorage.getItem('concursa_theme') || 'light';
  applyTheme(savedTheme);

  const toggleBtn = document.getElementById('theme-toggle');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'light';
      const next = current === 'light' ? 'dark' : 'light';
      applyTheme(next);
      localStorage.setItem('concursa_theme', next);
    });
  }
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  const icon = document.getElementById('theme-icon');
  const text = document.getElementById('theme-text');
  if (icon && text) {
    if (theme === 'dark') {
      icon.textContent = '🌙';
      text.textContent = 'Modo Escuro';
    } else {
      icon.textContent = '☀️';
      text.textContent = 'Modo Claro';
    }
  }
}

// ============================================================
// ROUTING
// ============================================================

async function handleRoute() {
  const hash = window.location.hash.substring(1) || 'dashboard';
  const route = routes[hash] || routes['dashboard'];
  
  // Update Navigation Active State
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('data-route') === hash) {
      item.classList.add('active');
    }
  });
  
  // Update Headers
  const titleEl = document.getElementById('page-title');
  const subtitleEl = document.getElementById('page-subtitle');
  if (titleEl) titleEl.textContent = route.title;
  if (subtitleEl) subtitleEl.textContent = route.subtitle;
  
  // Load Content
  const container = document.getElementById('page-content');
  if (!container) return;
  
  // Fade out
  container.style.opacity = 0;
  
  try {
    const module = await import(`./${route.file}`);
    setTimeout(async () => {
      container.innerHTML = ''; // Clear current
      await module.render(container);
      
      // Fade in
      container.style.opacity = 1;
      container.classList.remove('fade-in');
      void container.offsetWidth; 
      container.classList.add('fade-in');
    }, 150);
    
  } catch (error) {
    console.error('Error loading module:', error);
    showToast('Erro ao carregar o módulo.', 'error');
    container.innerHTML = `<div class="card"><h3 style="color:var(--color-danger)">Erro 404</h3><p>Módulo não encontrado.</p></div>`;
    container.style.opacity = 1;
  }
}

// Global utilities attached to window for easy use if needed
window.showToast = showToast;

// Initialize
window.addEventListener('hashchange', handleRoute);
window.addEventListener('DOMContentLoaded', () => {
  initTheme();
  if (!window.location.hash) {
    window.location.hash = '#dashboard';
  } else {
    handleRoute();
  }
});
