import { api } from './api.js';
import { getSubjectColor, formatDate, showToast } from './utils.js';

export async function render(container) {
  container.innerHTML = `
    <!-- Top Stats -->
    <div class="grid-4" style="margin-bottom: 1.5rem;">
      <div class="card stat-card slide-up" style="animation-delay: 0.1s; border-left: 4px solid var(--color-questions)">
        <div class="stat-icon" style="background: rgba(6, 182, 212, 0.2); color: var(--color-questions);">📝</div>
        <div class="stat-info">
          <h3 id="stat-answered">...</h3>
          <p>Questões Resolvidas</p>
        </div>
      </div>
      <div class="card stat-card slide-up" style="animation-delay: 0.2s; border-left: 4px solid var(--color-summaries)">
        <div class="stat-icon" style="background: rgba(16, 185, 129, 0.2); color: var(--color-summaries);">🎯</div>
        <div class="stat-info">
          <h3 id="stat-accuracy">...</h3>
          <p>Taxa de Acerto</p>
        </div>
      </div>
      <div class="card stat-card slide-up" style="animation-delay: 0.3s; border-left: 4px solid var(--color-flashcards)">
        <div class="stat-icon" style="background: rgba(249, 115, 22, 0.2); color: var(--color-flashcards);">🃏</div>
        <div class="stat-info">
          <h3 id="stat-cards">...</h3>
          <p>Flashcards Pendentes</p>
        </div>
      </div>
      <div class="card stat-card slide-up" style="animation-delay: 0.4s; border-left: 4px solid var(--color-simulados)">
        <div class="stat-icon" style="background: rgba(236, 72, 153, 0.2); color: var(--color-simulados);">⏱️</div>
        <div class="stat-info">
          <h3 id="stat-simulados">...</h3>
          <p>Simulados Feitos</p>
        </div>
      </div>
    </div>

    <!-- Matérias Atrasadas / Fila de Reposição Widget -->
    <div class="card slide-up" id="backlog-widget" style="margin-bottom: 1.5rem; border-left: 4px solid var(--color-warning);">
      <div class="card-header" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem;">
        <div style="display:flex; align-items:center; gap:0.75rem;">
          <span style="font-size:1.5rem;">🚨</span>
          <div>
            <h3 style="margin:0; font-size:1.1rem; color:var(--text-primary);">Fila de Reposição (Matérias Atrasadas / Pendências)</h3>
            <p style="font-size:0.82rem; margin-top:0.2rem; color:var(--text-secondary);">Não perca o ritmo: reponha estudos, questões ou revisões pendentes</p>
          </div>
        </div>
        <button class="btn btn-warning btn-sm" id="btn-add-backlog">
          ➕ Registrar Matéria Atrasada
        </button>
      </div>

      <div id="backlog-content" style="margin-top:1rem;">
        <div class="loading-placeholder">Carregando pendências de reposição...</div>
      </div>
    </div>

    <!-- Google Calendar Integration Widget -->
    <div class="card slide-up" id="calendar-today-widget" style="margin-bottom: 1.5rem; border-left: 4px solid var(--color-primary);">
      <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
        <div style="display:flex; align-items:center; gap:0.75rem;">
          <span style="font-size:1.5rem;">📅</span>
          <div>
            <h3 style="margin:0; font-size:1.1rem; color:var(--text-primary);">Matérias de Hoje na sua Google Agenda</h3>
            <p style="font-size:0.82rem; margin-top:0.2rem; color:var(--text-secondary);">Sincronizado automaticamente com sua rotina</p>
          </div>
        </div>
        <button class="btn btn-secondary btn-sm" id="btn-sync-calendar">🔄 Sincronizar</button>
      </div>

      <div id="calendar-today-content" style="margin-top:1rem;">
        <div class="loading-placeholder">Verificando Google Agenda...</div>
      </div>
    </div>

    <!-- Charts & Recent Activity -->
    <div class="grid-2 slide-up" style="animation-delay: 0.5s;">
      <div class="card">
        <h3>Pontos Fortes e Fracos</h3>
        <p style="color: var(--text-muted); margin-bottom: 1rem;">Baseado nas suas últimas questões da Receita Federal</p>
        <div style="display:flex; flex-direction:column; gap:1rem;">
          <div>
            <div style="display:flex; justify-content:space-between; margin-bottom:0.25rem;">
              <span>Direito Tributário</span>
              <span style="color:var(--color-summaries)">88%</span>
            </div>
            <div style="width:100%; background:var(--bg-tertiary); height:8px; border-radius:4px;">
              <div style="width:88%; background:var(--color-summaries); height:100%; border-radius:4px;"></div>
            </div>
          </div>
          <div>
            <div style="display:flex; justify-content:space-between; margin-bottom:0.25rem;">
              <span>Língua Portuguesa</span>
              <span style="color:var(--color-tutor)">75%</span>
            </div>
            <div style="width:100%; background:var(--bg-tertiary); height:8px; border-radius:4px;">
              <div style="width:75%; background:var(--color-tutor); height:100%; border-radius:4px;"></div>
            </div>
          </div>
          <div>
            <div style="display:flex; justify-content:space-between; margin-bottom:0.25rem;">
              <span>Fluência de Dados</span>
              <span style="color:var(--color-edital)">60%</span>
            </div>
            <div style="width:100%; background:var(--bg-tertiary); height:8px; border-radius:4px;">
              <div style="width:60%; background:var(--color-edital); height:100%; border-radius:4px;"></div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="card">
        <h3>Atalhos Rápidos</h3>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.75rem; margin-top:1rem;">
          <button class="btn btn-primary" onclick="window.location.hash='#study-room'" style="padding:1rem;">
            📖 Sala de Estudos (Apostila)
          </button>
          <button class="btn btn-secondary" onclick="window.location.hash='#simulados'" style="padding:1rem;">
            🎯 Novo Simulado FGV
          </button>
          <button class="btn btn-secondary" onclick="window.location.hash='#tutor'" style="padding:1rem;">
            🤖 Perguntar ao Tutor IA
          </button>
          <button class="btn btn-secondary" onclick="window.location.hash='#schedule'" style="padding:1rem;">
            📅 Configurar Agenda
          </button>
        </div>
      </div>
    </div>
  `;

  // Fetch Stats
  try {
    const stats = await api.dashboard.getStats();
    animateValue("stat-answered", 0, stats.answered || 0, 1500);
    animateValue("stat-accuracy", 0, stats.accuracy || 0, 1500, "%");
    animateValue("stat-cards", 0, stats.pendingCards || 0, 1500);
    animateValue("stat-simulados", 0, stats.simulados || 0, 1500);
  } catch(e) {}

  loadBacklog();
  loadTodayCalendar();
  
  document.getElementById('btn-sync-calendar')?.addEventListener('click', loadTodayCalendar);
  document.getElementById('btn-add-backlog')?.addEventListener('click', showAddBacklogDialog);
}

// ============================================================
// BACKLOG & MISSED SESSIONS
// ============================================================

async function loadBacklog() {
  const container = document.getElementById('backlog-content');
  if (!container) return;

  try {
    const res = await fetch('/api/backlog');
    const data = await res.json();

    const manual = data.manualBacklog || [];
    const unreviewed = data.unreviewedMaterials || [];
    const spaced = data.spacedReviews || [];
    const overdue = spaced.filter(r => r.timeline_status === 'overdue');
    const todayReviews = spaced.filter(r => r.timeline_status === 'today');

    if (manual.length === 0 && unreviewed.length === 0 && overdue.length === 0 && todayReviews.length === 0) {
      container.innerHTML = `
        <div style="padding:1rem; background:rgba(16, 185, 129, 0.1); border-left:3px solid #10B981; border-radius:4px; font-size:0.9rem;">
          <strong style="color:#34D399;">🎉 Nenhum atraso pendente!</strong>
          <p style="margin:0.25rem 0 0 0; color:var(--text-secondary); font-size:0.85rem;">Seu cronograma de estudos e revisões espaçadas estão 100% em dia.</p>
        </div>
      `;
      return;
    }

    let itemsHtml = '';

    // 1. Render Overdue Spaced Reviews first (D+1, D+7, D+30)
    overdue.forEach(rev => {
      const subjectColor = getSubjectColor(rev.subject);
      const revTypeLabel = rev.review_type === 'd1' ? '24 Horas (D+1)' : (rev.review_type === 'd7' ? '7 Dias (D+7)' : '30 Dias (D+30)');
      itemsHtml += `
        <div style="display:flex; justify-content:space-between; align-items:center; padding:0.85rem 1rem; background:var(--color-danger-bg); border-radius:var(--radius-sm); border:1px solid rgba(220, 38, 38, 0.25); flex-wrap:wrap; gap:0.75rem;">
          <div style="display:flex; align-items:center; gap:0.75rem;">
            <span style="font-size:1.4rem;">⚠️</span>
            <div>
              <div style="display:flex; align-items:center; gap:0.5rem; flex-wrap:wrap;">
                <span class="badge badge-${subjectColor}">${rev.subject}</span>
                <span class="badge badge-danger">Revisão ${revTypeLabel} ATRASADA</span>
                <strong style="font-size:0.95rem; color:var(--text-primary);">${rev.material_title || `Aula ${rev.lesson_number}`}</strong>
              </div>
              <p style="margin:0.25rem 0 0 0; font-size:0.82rem; color:var(--color-danger); font-weight:500;">
                ⏰ Venceu em <strong>${formatDate(rev.scheduled_date)}</strong> (Estudada em ${formatDate(rev.studied_at)}). Reponha hoje!
              </p>
            </div>
          </div>

          <div style="display:flex; gap:0.5rem; align-items:center;">
            <button class="btn btn-primary btn-sm" onclick="window.location.hash='#study-room'">
              ▶️ Revisar na Sala
            </button>
            <button class="btn btn-success btn-sm btn-complete-review" data-id="${rev.id}" title="Marcar revisão como feita">
              ✅ Revisado
            </button>
          </div>
        </div>
      `;
    });

    // 2. Render Today Spaced Reviews
    todayReviews.forEach(rev => {
      const subjectColor = getSubjectColor(rev.subject);
      const revTypeLabel = rev.review_type === 'd1' ? '24 Horas (D+1)' : (rev.review_type === 'd7' ? '7 Dias (D+7)' : '30 Dias (D+30)');
      itemsHtml += `
        <div style="display:flex; justify-content:space-between; align-items:center; padding:0.85rem 1rem; background:var(--color-primary-bg); border-radius:var(--radius-sm); border:1px solid rgba(37, 99, 235, 0.25); flex-wrap:wrap; gap:0.75rem;">
          <div style="display:flex; align-items:center; gap:0.75rem;">
            <span style="font-size:1.4rem;">🔔</span>
            <div>
              <div style="display:flex; align-items:center; gap:0.5rem; flex-wrap:wrap;">
                <span class="badge badge-${subjectColor}">${rev.subject}</span>
                <span class="badge badge-primary">Revisão ${revTypeLabel} de Hoje</span>
                <strong style="font-size:0.95rem; color:var(--text-primary);">${rev.material_title || `Aula ${rev.lesson_number}`}</strong>
              </div>
              <p style="margin:0.25rem 0 0 0; font-size:0.82rem; color:var(--color-primary); font-weight:500;">
                Curva do Esquecimento agendada para hoje (${formatDate(rev.scheduled_date)}).
              </p>
            </div>
          </div>

          <div style="display:flex; gap:0.5rem; align-items:center;">
            <button class="btn btn-primary btn-sm" onclick="window.location.hash='#study-room'">
              ▶️ Revisar Aula
            </button>
            <button class="btn btn-success btn-sm btn-complete-review" data-id="${rev.id}">
              ✅ Revisado
            </button>
          </div>
        </div>
      `;
    });

    // 3. Render manual missed sessions
    manual.forEach(item => {
      const subjectColor = getSubjectColor(item.subject);
      itemsHtml += `
        <div style="display:flex; justify-content:space-between; align-items:center; padding:0.85rem 1rem; background:var(--bg-tertiary); border-radius:var(--radius-sm); border:1px solid var(--border-color); flex-wrap:wrap; gap:0.75rem;">
          <div style="display:flex; align-items:center; gap:0.75rem;">
            <span style="font-size:1.2rem;">📌</span>
            <div>
              <div style="display:flex; align-items:center; gap:0.5rem; flex-wrap:wrap;">
                <span class="badge badge-${subjectColor}">${item.subject}</span>
                <strong style="font-size:0.95rem; color:var(--text-primary);">${item.title || `Aula ${item.lesson_number}`}</strong>
                <span class="badge badge-warning" style="font-size:0.75rem;">Reposição: ${item.target_slot}</span>
              </div>
              <p style="margin:0.25rem 0 0 0; font-size:0.82rem; color:var(--text-secondary);">
                Motivo: ${item.reason || 'Estudo adiado'}
              </p>
            </div>
          </div>

          <div style="display:flex; gap:0.5rem; align-items:center;">
            <button class="btn btn-primary btn-sm" onclick="window.location.hash='#study-room'">
              ▶️ Repor Agora
            </button>
            <button class="btn btn-success btn-sm btn-resolve-backlog" data-id="${item.id}" title="Marcar como reposto">
              ✅ Concluído
            </button>
          </div>
        </div>
      `;
    });

    // 4. Render unreviewed materials
    unreviewed.forEach(mat => {
      const subjectColor = getSubjectColor(mat.subject);
      itemsHtml += `
        <div style="display:flex; justify-content:space-between; align-items:center; padding:0.85rem 1rem; background:var(--color-warning-bg); border-radius:var(--radius-sm); border:1px solid rgba(217, 119, 6, 0.25); flex-wrap:wrap; gap:0.75rem;">
          <div style="display:flex; align-items:center; gap:0.75rem;">
            <span style="font-size:1.2rem;">📝</span>
            <div>
              <div style="display:flex; align-items:center; gap:0.5rem;">
                <span class="badge badge-${subjectColor}">${mat.subject}</span>
                <strong style="font-size:0.95rem; color:var(--text-primary);">${mat.title}</strong>
              </div>
              <p style="margin:0.25rem 0 0 0; font-size:0.82rem; color:var(--color-warning); font-weight:500;">
                ⚠️ <strong>Pendente:</strong> Leitura realizada, mas ainda não foram feitas as questões de fixação da aula.
              </p>
            </div>
          </div>

          <button class="btn btn-primary btn-sm" onclick="window.location.hash='#study-room'">
            🎯 Fazer Questões de Fixação
          </button>
        </div>
      `;
    });

    container.innerHTML = `<div style="display:flex; flex-direction:column; gap:0.6rem;">${itemsHtml}</div>`;

    container.querySelectorAll('.btn-resolve-backlog').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.id;
        try {
          const res = await fetch(`/api/backlog/${id}/resolve`, { method: 'PUT' });
          if (res.ok) {
            showToast('Reposição concluída! Parabéns pelo foco. 🎯', 'success');
            loadBacklog();
          }
        } catch (e) {
          showToast('Erro ao atualizar reposição.', 'error');
        }
      });
    });

    container.querySelectorAll('.btn-complete-review').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.id;
        try {
          const res = await fetch(`/api/backlog/reviews/${id}/complete`, { method: 'PUT' });
          if (res.ok) {
            showToast('Revisão espaçada registrada com sucesso! 🧠🎉', 'success');
            loadBacklog();
          }
        } catch (e) {
          showToast('Erro ao registrar revisão.', 'error');
        }
      });
    });

  } catch (error) {
    console.error('Backlog load error:', error);
    container.innerHTML = `<p class="text-muted" style="font-size:0.85rem;">Não foi possível carregar as reposições.</p>`;
  }
}

function showAddBacklogDialog() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal card">
      <h3>🚨 Registrar Matéria Atrasada / Reposição</h3>
      <p class="text-muted" style="font-size:0.85rem;">Registre o que não deu tempo de estudar para não deixar a matéria esquecida.</p>

      <div class="form-group" style="margin-top:1rem;">
        <label for="b-subject">Disciplina</label>
        <select id="b-subject" class="form-control">
          <option value="Direito Tributário" selected>Direito Tributário</option>
          <option value="Direito Previdenciário">Direito Previdenciário</option>
          <option value="Língua Portuguesa">Língua Portuguesa</option>
          <option value="Fluência de Dados">Fluência de Dados</option>
          <option value="Direito Constitucional">Direito Constitucional</option>
          <option value="Legislação Tributária">Legislação Tributária</option>
          <option value="Legislação Aduaneira">Legislação Aduaneira</option>
          <option value="Direito Administrativo">Direito Administrativo</option>
          <option value="Raciocínio Lógico Matemático">Raciocínio Lógico Matemático</option>
          <option value="Contabilidade Geral">Contabilidade Geral</option>
        </select>
      </div>

      <div class="grid-2">
        <div class="form-group">
          <label for="b-lesson">Nº da Aula (ex: 1)</label>
          <input type="number" id="b-lesson" class="form-control" placeholder="1" value="1">
        </div>
        <div class="form-group">
          <label for="b-slot">Quando pretende repor?</label>
          <select id="b-slot" class="form-control">
            <option value="Hoje à noite" selected>Hoje à noite</option>
            <option value="Amanhã de manhã">Amanhã de manhã</option>
            <option value="Amanhã à noite">Amanhã à noite</option>
            <option value="Fim de semana (Sábado/Domingo)">Fim de semana</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label for="b-reason">O que ficou pendente?</label>
        <input type="text" id="b-reason" class="form-control" placeholder="Ex: Não fiz as questões / Falta revisar / Bloco da manhã adiado" value="Faltou fazer questões e revisar">
      </div>

      <div class="modal-actions">
        <button class="btn btn-secondary" id="btn-cancel-backlog">Cancelar</button>
        <button class="btn btn-primary" id="btn-confirm-backlog">Salvar na Fila de Reposição</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  overlay.querySelector('#btn-cancel-backlog').onclick = () => overlay.remove();

  overlay.querySelector('#btn-confirm-backlog').onclick = async () => {
    const subject = overlay.querySelector('#b-subject').value;
    const lessonNumber = parseInt(overlay.querySelector('#b-lesson').value, 10) || null;
    const targetSlot = overlay.querySelector('#b-slot').value;
    const reason = overlay.querySelector('#b-reason').value;

    try {
      const res = await fetch('/api/backlog', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject,
          lessonNumber,
          title: `Aula ${lessonNumber || 'Pendente'}`,
          reason,
          targetSlot
        })
      });

      if (res.ok) {
        showToast('Matéria adicionada à fila de reposição!', 'success');
        overlay.remove();
        loadBacklog();
      } else {
        showToast('Erro ao salvar reposição.', 'error');
      }
    } catch (e) {
      showToast('Erro ao conectar ao servidor.', 'error');
    }
  };
}

// ============================================================
// GOOGLE CALENDAR TODAY
// ============================================================

async function loadTodayCalendar() {
  const container = document.getElementById('calendar-today-content');
  if (!container) return;

  container.innerHTML = `<div class="loading-placeholder">Sincronizando com a Google Agenda...</div>`;

  try {
    const res = await fetch('/api/schedule/calendar/today');
    const data = await res.json();

    if (!data.success) {
      container.innerHTML = `
        <div style="padding:1rem; background:var(--color-warning-bg); border-left:3px solid var(--color-warning); border-radius:4px; font-size:0.9rem;">
          <div style="font-weight:700; color:var(--color-warning); margin-bottom:0.25rem;">🔗 Conectar sua Google Agenda</div>
          <p style="margin:0; color:var(--text-secondary); font-size:0.85rem;">
            ${data.error || 'Configure o Endereço Secreto iCal da sua agenda para puxar suas matérias do dia automaticamente.'}
          </p>
          <button class="btn btn-primary btn-sm" onclick="window.location.hash='#schedule'" style="margin-top:0.75rem;">
            ⚙️ Configurar Link da Agenda no Cronograma
          </button>
        </div>
      `;
      return;
    }

    if (!data.events || data.events.length === 0) {
      container.innerHTML = `
        <div style="padding:1rem; background:var(--bg-tertiary); border-radius:var(--radius-sm); border:1px solid var(--border-color); font-size:0.9rem; display:flex; justify-content:space-between; align-items:center;">
          <div>
            <span style="font-weight:700; color:var(--text-primary);">Nenhuma matéria agendada para hoje</span>
            <p style="margin:0.2rem 0 0 0; font-size:0.82rem; color:var(--text-secondary);">Sua agenda está livre ou seus blocos foram marcados em outros horários.</p>
          </div>
          <button class="btn btn-primary btn-sm" onclick="window.location.hash='#study-room'">
            📖 Ver Biblioteca de Aulas
          </button>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div style="display:flex; flex-direction:column; gap:0.6rem;">
        ${data.events.map(ev => {
          const subjectColor = ev.subject ? getSubjectColor(ev.subject) : 'secondary';
          const lessonLabel = ev.lessonNumber !== null ? `Aula ${ev.lessonNumber}` : '';

          return `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:0.85rem 1rem; background:var(--bg-tertiary); border-radius:var(--radius-sm); border:1px solid var(--border-color); flex-wrap:wrap; gap:0.75rem;">
              <div style="display:flex; align-items:center; gap:0.75rem;">
                <span style="font-family:'Outfit',sans-serif; font-weight:700; color:var(--color-primary); font-size:0.9rem; min-width:85px;">
                  ⏱️ ${ev.timeDisplay}
                </span>
                <div>
                  <div style="font-weight:700; font-size:0.95rem; color:var(--text-primary);">${ev.summary}</div>
                  <div style="display:flex; gap:0.5rem; margin-top:0.2rem; align-items:center;">
                    ${ev.subject ? `<span class="badge badge-${subjectColor}">${ev.subject}</span>` : ''}
                    ${lessonLabel ? `<span class="badge badge-primary">${lessonLabel}</span>` : ''}
                  </div>
                </div>
              </div>

              <button class="btn btn-primary btn-sm" onclick="window.location.hash='#study-room'">
                ▶️ Estudar Aula
              </button>
            </div>
          `;
        }).join('')}
      </div>
    `;

  } catch (error) {
    container.innerHTML = `
      <p class="text-muted" style="font-size:0.85rem;">Não foi possível consultar a Google Agenda no momento.</p>
    `;
  }
}

function animateValue(id, start, end, duration, suffix = "") {
  const obj = document.getElementById(id);
  if (!obj) return;
  let startTimestamp = null;
  const step = (timestamp) => {
    if (!startTimestamp) startTimestamp = timestamp;
    const progress = Math.min((timestamp - startTimestamp) / duration, 1);
    obj.innerHTML = Math.floor(progress * (end - start) + start) + suffix;
    if (progress < 1) {
      window.requestAnimationFrame(step);
    }
  };
  window.requestAnimationFrame(step);
}
