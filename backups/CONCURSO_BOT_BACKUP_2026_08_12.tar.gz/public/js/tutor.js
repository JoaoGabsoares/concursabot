import { api } from './api.js';
import { parseMarkdown } from './utils.js';

export async function render(container) {
  container.innerHTML = `
    <div class="chat-container slide-up">
      <div class="chat-sidebar card">
        <h3>Matéria</h3>
        <select id="chat-subject" class="form-group">
          <option value="Direito Constitucional">Direito Constitucional</option>
          <option value="Direito Administrativo">Direito Administrativo</option>
          <option value="Direito Tributário">Direito Tributário</option>
          <option value="Legislação Aduaneira">Legislação Aduaneira</option>
          <option value="Direito Penal">Direito Penal</option>
          <option value="Português">Português</option>
          <option value="Fluência de Dados">Fluência de Dados</option>
          <option value="Informática">Informática</option>
          <option value="Geral">Geral</option>
        </select>
        
        <button id="btn-new-chat" class="btn btn-primary" style="width:100%; margin-bottom:1rem;">+ Novo Chat</button>
        
        <h4 style="color:var(--text-muted); font-size:0.8rem; text-transform:uppercase;">Histórico</h4>
        <div id="chat-history-list" style="display:flex; flex-direction:column; gap:0.5rem; margin-top:0.5rem; overflow-y:auto; flex:1; max-height:400px;">
          <div style="font-size:0.85rem; color:var(--text-muted); padding:0.5rem;">Carregando histórico...</div>
        </div>
      </div>
      
      <div class="chat-main card" style="padding:0; border:1px solid var(--glass-border);">
        <div id="chat-messages" class="chat-messages">
          <div class="message model">
            <div class="markdown-content">
              <p>Olá! Sou seu Tutor IA focado em concursos. Qual sua dúvida sobre <strong>Direito Constitucional</strong> hoje?</p>
            </div>
          </div>
        </div>
        
        <div class="chat-input-area">
          <textarea id="chat-input" placeholder="Digite sua dúvida aqui... (Ex: Qual a diferença entre descentralização e desconcentração?)"></textarea>
          <button id="btn-send" class="btn btn-primary" style="align-self:flex-end;">Enviar</button>
        </div>
      </div>
    </div>
  `;

  const input = document.getElementById('chat-input');
  const btnSend = document.getElementById('btn-send');
  const btnNewChat = document.getElementById('btn-new-chat');
  const messagesDiv = document.getElementById('chat-messages');
  const subjectSelect = document.getElementById('chat-subject');
  const historyList = document.getElementById('chat-history-list');
  
  let currentSessionId = null;
  let isTyping = false;

  async function loadHistoryList() {
    try {
      const sessions = await api.tutor.getSessions();
      if (!sessions || sessions.length === 0) {
        historyList.innerHTML = '<div style="font-size:0.85rem; color:var(--text-muted); padding:0.5rem;">Nenhum chat anterior.</div>';
        return;
      }

      historyList.innerHTML = '';
      sessions.forEach(s => {
        const item = document.createElement('div');
        const isActive = s.id === currentSessionId;
        item.className = `nav-item ${isActive ? 'active' : ''}`;
        item.style.cssText = 'font-size:0.85rem; padding:0.5rem; cursor:pointer; display:flex; justify-content:space-between; align-items:center; border-radius:6px;';
        
        const titleSpan = document.createElement('span');
        titleSpan.textContent = s.title || s.subject || 'Chat';
        titleSpan.style.cssText = 'white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:140px;';
        
        const delBtn = document.createElement('button');
        delBtn.innerHTML = '×';
        delBtn.style.cssText = 'background:none; border:none; color:var(--text-muted); cursor:pointer; font-size:1.1rem; padding:0 4px;';
        delBtn.title = 'Excluir chat';
        delBtn.onclick = async (e) => {
          e.stopPropagation();
          if (confirm('Deseja excluir esta conversa?')) {
            await api.tutor.deleteSession(s.id);
            if (currentSessionId === s.id) {
              startNewChat();
            } else {
              loadHistoryList();
            }
          }
        };

        item.appendChild(titleSpan);
        item.appendChild(delBtn);

        item.onclick = () => loadSession(s.id, s.subject);
        historyList.appendChild(item);
      });
    } catch (e) {
      console.error('Falha ao carregar lista de chats:', e);
      historyList.innerHTML = '<div style="font-size:0.85rem; color:var(--text-muted); padding:0.5rem;">Histórico indisponível</div>';
    }
  }

  async function loadSession(sessionId, subject) {
    if (isTyping) return;
    currentSessionId = sessionId;
    if (subject) subjectSelect.value = subject;
    
    messagesDiv.innerHTML = '<div style="text-align:center; padding:1rem; color:var(--text-muted);">Carregando mensagens...</div>';
    
    try {
      const data = await api.tutor.getHistory(sessionId);
      const messages = (data && data.messages) ? data.messages : (Array.isArray(data) ? data : []);
      
      messagesDiv.innerHTML = '';
      if (messages.length === 0) {
        messagesDiv.innerHTML = `
          <div class="message model">
            <div class="markdown-content">
              <p>Esta conversa está vazia. Como posso te ajudar com <strong>${subjectSelect.value}</strong>?</p>
            </div>
          </div>`;
      } else {
        messages.forEach(m => {
          appendMessage(m.text, m.role === 'model' ? 'model' : 'user');
        });
      }
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
      loadHistoryList();
    } catch (e) {
      console.error('Erro ao carregar histórico da sessão:', e);
      messagesDiv.innerHTML = '<p style="color:var(--color-edital); padding:1rem;">Erro ao carregar mensagens desta conversa.</p>';
    }
  }

  function startNewChat() {
    if (isTyping) return;
    currentSessionId = null;
    messagesDiv.innerHTML = `
      <div class="message model">
        <div class="markdown-content">
          <p>Olá! Sou seu Tutor IA focado em concursos. Qual sua dúvida sobre <strong>${subjectSelect.value}</strong> hoje?</p>
        </div>
      </div>
    `;
    input.value = '';
    loadHistoryList();
  }

  async function sendMessage() {
    const text = input.value.trim();
    if (!text || isTyping) return;
    
    input.value = '';
    const subject = subjectSelect.value;
    
    // Add user message
    appendMessage(text, 'user');
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
    
    // Add typing indicator
    const typingIndicator = document.createElement('div');
    typingIndicator.className = 'message model';
    typingIndicator.innerHTML = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
    messagesDiv.appendChild(typingIndicator);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
    
    isTyping = true;
    
    // Prepare for streaming response
    const modelMsg = document.createElement('div');
    modelMsg.className = 'message model markdown-content';
    let currentHtml = '';
    let isFirstChunk = true;
    
    try {
      await api.tutor.chat(
        currentSessionId,
        text,
        subject,
        (chunk) => {
          if (isFirstChunk) {
            if (typingIndicator.parentNode) typingIndicator.remove();
            if (!modelMsg.parentNode) messagesDiv.appendChild(modelMsg);
            isFirstChunk = false;
          }
          currentHtml += chunk;
          modelMsg.innerHTML = parseMarkdown(currentHtml);
          messagesDiv.scrollTop = messagesDiv.scrollHeight;
        },
        (newSessionId) => {
          if (!currentSessionId || currentSessionId !== newSessionId) {
            currentSessionId = newSessionId;
            loadHistoryList();
          }
        }
      );
    } catch (e) {
      if (typingIndicator.parentNode) typingIndicator.remove();
      modelMsg.innerHTML = '<p style="color:var(--color-edital)">Ocorreu um erro ao comunicar com a IA.</p>';
      if (!modelMsg.parentNode) messagesDiv.appendChild(modelMsg);
    }
    
    isTyping = false;
    loadHistoryList();
  }

  btnSend.addEventListener('click', sendMessage);
  btnNewChat.addEventListener('click', startNewChat);

  subjectSelect.addEventListener('change', () => {
    if (!currentSessionId && messagesDiv.children.length <= 1) {
      startNewChat();
    }
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  function appendMessage(text, sender) {
    const div = document.createElement('div');
    div.className = `message ${sender}`;
    div.innerHTML = sender === 'user' ? `<p>${text}</p>` : parseMarkdown(text);
    messagesDiv.appendChild(div);
  }

  // Load past history list on initial render
  loadHistoryList();
}
