import { showToast, parseMarkdown, formatDate } from './utils.js';

// ============================================================
// BASE DE CONHECIMENTO RAG — Global Multi-PDF Intelligence
// ============================================================

export async function render(container) {
  container.innerHTML = `
    <div class="rag-container slide-up">
      <!-- Top Stats Bar -->
      <div class="grid-4" style="margin-bottom: 1.5rem;">
        <div class="card stat-card" style="border-left: 4px solid var(--color-tutor);">
          <div class="stat-icon" style="background: rgba(59, 130, 246, 0.2); color: var(--color-tutor);">📚</div>
          <div class="stat-info">
            <h3 id="rag-stat-docs">0</h3>
            <p>PDFs Indexados</p>
          </div>
        </div>
        <div class="card stat-card" style="border-left: 4px solid var(--color-questions);">
          <div class="stat-icon" style="background: rgba(6, 182, 212, 0.2); color: var(--color-questions);">🔢</div>
          <div class="stat-info">
            <h3 id="rag-stat-chunks">0</h3>
            <p>Trechos Vetoriais (RAG)</p>
          </div>
        </div>
        <div class="card stat-card" style="border-left: 4px solid var(--color-summaries);">
          <div class="stat-icon" style="background: rgba(16, 185, 129, 0.2); color: var(--color-summaries);">⚡</div>
          <div class="stat-info">
            <h3>text-embedding-004</h3>
            <p>Modelo de Vetores (Grátis)</p>
          </div>
        </div>
        <div class="card stat-card" style="border-left: 4px solid var(--color-flashcards);">
          <div class="stat-icon" style="background: rgba(249, 115, 22, 0.2); color: var(--color-flashcards);">🔍</div>
          <div class="stat-info">
            <h3>Busca Semântica</h3>
            <p>Similaridade por Cosseno</p>
          </div>
        </div>
      </div>

      <!-- Main Search & Question Interface -->
      <div class="card" style="margin-bottom: 1.5rem;">
        <div class="card-header">
          <h3>🔎 Pesquisa e Consulta Global em Todos os PDFs</h3>
          <p class="text-muted" style="font-size: 0.9rem;">
            Faça perguntas ou pesquise termos. A IA cruzará todo o seu acervo de PDFs e responderá citando as páginas e arquivos exatos.
          </p>
        </div>

        <div style="display: flex; gap: 0.75rem; margin-top: 1rem;">
          <select id="rag-subject-filter" class="form-control" style="max-width: 220px;">
            <option value="Todas">Todas as Matérias</option>
            <option value="Direito Tributário">Direito Tributário</option>
            <option value="Direito Constitucional">Direito Constitucional</option>
            <option value="Direito Administrativo">Direito Administrativo</option>
            <option value="Direito Penal">Direito Penal</option>
            <option value="Português">Português</option>
            <option value="Raciocínio Lógico">Raciocínio Lógico</option>
            <option value="Informática">Informática</option>
            <option value="AFO / Contabilidade">AFO / Contabilidade</option>
          </select>
          <input type="text" id="rag-query-input" class="form-control" placeholder="Ex: Qual a regra de imunidade tributária recíproca para empresas públicas?">
          <button class="btn btn-primary" id="btn-rag-ask">
            <span>🧠 Consultar IA (RAG)</span>
          </button>
          <button class="btn btn-secondary" id="btn-rag-search">
            <span>🔍 Buscar Trechos</span>
          </button>
        </div>
      </div>

      <!-- RAG Results Area -->
      <div id="rag-loading" style="display: none; text-align: center; padding: 3rem;">
        <div class="loading-spinner"></div>
        <p style="margin-top: 1rem; color: var(--text-muted);">Consultando banco vetorial e sintetizando resposta...</p>
      </div>

      <div id="rag-answer-card" class="card" style="display: none; margin-bottom: 1.5rem; border-left: 4px solid var(--color-summaries);">
        <h4 style="color: var(--color-summaries); margin-bottom: 1rem;">💡 Resposta Fundamentada na sua Base de PDFs</h4>
        <div id="rag-answer-content" class="markdown-content"></div>
        <div id="rag-sources-container" style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--glass-border);">
          <h5 style="color: var(--text-muted); font-size: 0.85rem; text-transform: uppercase;">📂 Fontes Citadas</h5>
          <div id="rag-sources-list" style="display: flex; flex-direction: column; gap: 0.5rem; margin-top: 0.5rem;"></div>
        </div>
      </div>

      <div id="rag-search-results" class="card" style="display: none; margin-bottom: 1.5rem;">
        <h4>📄 Trechos Mais Relevantes Encontrados</h4>
        <div id="rag-search-list" style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1rem;"></div>
      </div>

      <!-- Ingestion Guide & Indexed Documents Library -->
      <div class="grid-2">
        <!-- Ingestion Box -->
        <div class="card">
          <div class="card-header">
            <h3>⚡ Como Indexar Seus 1.000 PDFs</h3>
          </div>
          <p style="font-size: 0.9rem; color: var(--text-secondary); line-height: 1.5;">
            Para indexar seus PDFs do Google Drive ou da sua máquina de uma só vez, abra o terminal na pasta do projeto e rode:
          </p>
          <div style="background: var(--bg-tertiary); padding: 0.75rem 1rem; border-radius: var(--radius-sm); font-family: monospace; font-size: 0.85rem; margin: 1rem 0; display: flex; justify-content: space-between; align-items: center;">
            <code id="ingest-cmd">npm run ingest -- "C:\\caminho\\para\\seus\\pdfs"</code>
            <button class="btn btn-sm btn-secondary" id="btn-copy-cmd">📋 Copiar</button>
          </div>
          <p style="font-size: 0.8rem; color: var(--text-muted);">
            💡 O script varre todas as subpastas automaticamente, extrai os textos, gera os embeddings vetoriais com a API gratuita do Gemini e salva no SQLite.
          </p>
        </div>

        <!-- Indexed Documents List -->
        <div class="card">
          <div class="card-header">
            <h3>📑 Documentos Indexados</h3>
          </div>
          <div id="rag-docs-list" style="max-height: 250px; overflow-y: auto; display: flex; flex-direction: column; gap: 0.5rem; margin-top: 0.5rem;">
            <div class="loading-placeholder">Carregando acervo...</div>
          </div>
        </div>
      </div>
    </div>
  `;

  // Initialize
  setupRAGHandlers();
  loadRAGStats();
  loadRAGDocuments();
}

// Event Handlers
function setupRAGHandlers() {
  const queryInput = document.getElementById('rag-query-input');
  const btnAsk = document.getElementById('btn-rag-ask');
  const btnSearch = document.getElementById('btn-rag-search');
  const btnCopy = document.getElementById('btn-copy-cmd');

  btnAsk.addEventListener('click', handleRAGAsk);
  btnSearch.addEventListener('click', handleRAGSearch);
  
  queryInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleRAGAsk();
  });

  btnCopy.addEventListener('click', () => {
    const cmd = document.getElementById('ingest-cmd').textContent;
    navigator.clipboard.writeText(cmd);
    showToast('Comando copiado para a área de transferência!', 'success');
  });
}

// Load Stats
async function loadRAGStats() {
  try {
    const res = await fetch('/api/rag/stats');
    if (!res.ok) return;
    const data = await res.json();
    document.getElementById('rag-stat-docs').textContent = data.totalDocuments || 0;
    document.getElementById('rag-stat-chunks').textContent = data.totalChunks || 0;
  } catch (e) {}
}

// Load Indexed Docs
async function loadRAGDocuments() {
  const container = document.getElementById('rag-docs-list');
  try {
    const res = await fetch('/api/rag/documents');
    if (!res.ok) {
      container.innerHTML = `<p class="text-muted" style="font-size:0.85rem;">Nenhum documento indexado ainda. Use o comando de ingestão.</p>`;
      return;
    }
    const data = await res.json();
    if (!data.documents || data.documents.length === 0) {
      container.innerHTML = `<p class="text-muted" style="font-size:0.85rem;">Nenhum documento indexado ainda. Use o comando de ingestão acima para carregar sua pasta.</p>`;
      return;
    }

    container.innerHTML = data.documents.map(d => `
      <div style="display:flex; justify-content:space-between; align-items:center; padding:0.5rem 0.75rem; background:var(--bg-tertiary); border-radius:var(--radius-sm); font-size:0.85rem;">
        <div>
          <strong>📄 ${d.filename}</strong>
          <span class="badge badge-primary" style="margin-left:0.5rem;">${d.subject}</span>
        </div>
        <span class="text-muted">${d.total_chunks} trechos</span>
      </div>
    `).join('');
  } catch (e) {
    container.innerHTML = `<p class="text-muted" style="font-size:0.85rem;">Aguardando indexação dos primeiros PDFs.</p>`;
  }
}

// Handle Ask Question via RAG
async function handleRAGAsk() {
  const question = document.getElementById('rag-query-input').value.trim();
  const subject = document.getElementById('rag-subject-filter').value;

  if (!question) {
    showToast('Digite uma dúvida para consultar a base de conhecimento.', 'warning');
    return;
  }

  const loading = document.getElementById('rag-loading');
  const answerCard = document.getElementById('rag-answer-card');
  const searchCard = document.getElementById('rag-search-results');

  loading.style.display = 'block';
  answerCard.style.display = 'none';
  searchCard.style.display = 'none';

  try {
    const res = await fetch('/api/rag/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, subject })
    });

    const data = await res.json();
    loading.style.display = 'none';

    document.getElementById('rag-answer-content').innerHTML = parseMarkdown(data.answer);
    
    // Render Sources
    const sourcesContainer = document.getElementById('rag-sources-list');
    if (data.sources && data.sources.length > 0) {
      sourcesContainer.innerHTML = data.sources.map(s => `
        <div style="background:var(--bg-tertiary); padding:0.5rem 0.75rem; border-radius:var(--radius-sm); font-size:0.85rem; display:flex; justify-content:space-between; align-items:center;">
          <span>📄 <strong>${s.filename}</strong> (${s.subject})</span>
          <span class="badge badge-success">Relevância: ${s.score}%</span>
        </div>
      `).join('');
    } else {
      sourcesContainer.innerHTML = `<p class="text-muted" style="font-size:0.8rem;">Conhecimento geral da IA.</p>`;
    }

    answerCard.style.display = 'block';

  } catch (e) {
    loading.style.display = 'none';
    showToast('Erro ao consultar RAG. Verifique se o servidor está ativo.', 'error');
  }
}

// Handle Semantic Search
async function handleRAGSearch() {
  const query = document.getElementById('rag-query-input').value.trim();
  const subject = document.getElementById('rag-subject-filter').value;

  if (!query) {
    showToast('Digite um termo para pesquisar.', 'warning');
    return;
  }

  const loading = document.getElementById('rag-loading');
  const searchCard = document.getElementById('rag-search-results');
  const answerCard = document.getElementById('rag-answer-card');

  loading.style.display = 'block';
  searchCard.style.display = 'none';
  answerCard.style.display = 'none';

  try {
    const res = await fetch('/api/rag/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, subject, topK: 5 })
    });

    const data = await res.json();
    loading.style.display = 'none';

    const searchList = document.getElementById('rag-search-list');
    if (!data.results || data.results.length === 0) {
      searchList.innerHTML = `<p class="text-muted">Nenhum trecho encontrado com similaridade semântica.</p>`;
    } else {
      searchList.innerHTML = data.results.map((r, i) => `
        <div style="background:var(--bg-tertiary); border-left:4px solid var(--color-tutor); padding:1rem; border-radius:var(--radius-sm);">
          <div style="display:flex; justify-content:space-between; margin-bottom:0.5rem;">
            <strong>📄 ${r.filename} <span class="badge badge-info">${r.subject}</span></strong>
            <span class="badge badge-success">Similaridade: ${Math.round(r.score * 100)}%</span>
          </div>
          <p style="font-size:0.9rem; color:var(--text-secondary); line-height:1.5;">${r.content}</p>
        </div>
      `).join('');
    }

    searchCard.style.display = 'block';

  } catch (e) {
    loading.style.display = 'none';
    showToast('Erro ao realizar busca vetorial.', 'error');
  }
}
