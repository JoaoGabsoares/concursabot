import { showToast, renderMarkdown, formatDate, getSubjectColor } from './utils.js';

// ============================================================
// SALA DE ESTUDOS — Study Room Module
// ============================================================

let currentSession = null;
let timerInterval = null;
let remainingSeconds = 0;
let timerAudioPlayed = false;

export async function render(container) {
  container.innerHTML = `
    <div class="study-room">
      <!-- Top: Upload & Global Overview -->
      <div class="study-room-top">
        <div class="card study-upload-card">
          <div class="card-header">
            <h3>📄 Upload de Material (Apostila / PDF)</h3>
          </div>
          <div class="upload-area" id="upload-area">
            <div class="upload-dropzone" id="upload-dropzone">
              <span class="upload-icon">📂</span>
              <p>Arraste seu PDF aqui ou <label for="file-input" class="upload-link">clique para selecionar</label></p>
              <p class="text-muted" style="font-size: 0.8rem; margin-top: 0.5rem;">Suporta arquivos PDF (ex: Aula 01_Apostila_Grifada.pdf)</p>
              <input type="file" id="file-input" accept=".pdf" style="display:none;">
            </div>
            <div class="upload-config" id="upload-config" style="display:none; padding:1.25rem; background:var(--bg-tertiary); border-radius:var(--radius-sm); border:1px solid var(--glass-border); margin-top:1rem;">
              <div class="upload-file-info" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem; padding-bottom:0.75rem; border-bottom:1px solid var(--glass-border);">
                <div style="display:flex; align-items:center; gap:0.5rem;">
                  <span class="upload-file-icon" style="font-size:1.4rem;">📄</span>
                  <span id="upload-filename" style="font-weight:600; font-size:0.95rem;"></span>
                </div>
                <button class="btn-icon" id="upload-remove" title="Remover" style="cursor:pointer;">✕</button>
              </div>

              <div class="grid-2">
                <div class="form-group">
                  <label for="upload-subject" style="font-weight:600;">Matéria do Concurso</label>
                  <select id="upload-subject" class="form-control">
                    <optgroup label="Wave 1 — Prioridade Alta (Receita Federal)">
                      <option value="Direito Tributário" selected>Direito Tributário (16q)</option>
                      <option value="Direito Previdenciário">Direito Previdenciário (16q)</option>
                      <option value="Língua Portuguesa">Língua Portuguesa (15q)</option>
                      <option value="Fluência de Dados">Fluência de Dados (15q)</option>
                      <option value="Direito Constitucional">Direito Constitucional (14q)</option>
                      <option value="Legislação Tributária">Legislação Tributária (14q)</option>
                      <option value="Legislação Aduaneira">Legislação Aduaneira (14q)</option>
                    </optgroup>
                    <optgroup label="Wave 2 — Complementar">
                      <option value="Direito Administrativo">Direito Administrativo (12q)</option>
                      <option value="Língua Inglesa">Língua Inglesa (10q)</option>
                      <option value="Raciocínio Lógico Matemático">Raciocínio Lógico Matemático (10q)</option>
                      <option value="Estatística">Estatística (10q)</option>
                      <option value="Contabilidade Geral">Contabilidade Geral (10q)</option>
                      <option value="Administração Geral e Pública">Administração Geral e Pública (10q)</option>
                    </optgroup>
                    <option value="Outra">Outra Disciplina</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="upload-study-status" style="font-weight:600;">Status do Estudo desta Aula</label>
                  <select id="upload-study-status" class="form-control">
                    <option value="theory_only" selected>⚠️ Apenas Teoria Lida (Revisão & Questões na Fila de Reposição)</option>
                    <option value="full">✅ Completo (Teoria Lida + Questões Feitas)</option>
                    <option value="unread">⚪ Material Apenas Salvo (Ainda não estudei)</option>
                  </select>
                </div>
              </div>

              <!-- Data Real de Estudo -->
              <div class="form-group" style="margin-top:0.75rem;">
                <label style="font-weight:600; display:flex; justify-content:space-between;">
                  <span>📅 Quando você estudou (ou pretende estudar) esta aula?</span>
                  <span class="text-muted" style="font-size:0.75rem;">Gera o ciclo D+1, D+7 e D+30</span>
                </label>
                
                <div style="display:flex; gap:0.4rem; flex-wrap:wrap; margin-top:0.35rem;" id="upload-date-quick-btns">
                  <button type="button" class="btn btn-secondary btn-sm date-pill-btn" data-date="2026-08-10">⏮️ Segunda (10/08)</button>
                  <button type="button" class="btn btn-secondary btn-sm date-pill-btn" data-date="2026-08-11">⏮️ Ontem (11/08)</button>
                  <button type="button" class="btn btn-secondary btn-sm date-pill-btn active" data-date="2026-08-12">⭐ Hoje (12/08)</button>
                  <button type="button" class="btn btn-secondary btn-sm date-pill-btn" data-date="custom">📅 Outra Data</button>
                </div>

                <input type="date" id="upload-custom-date" class="form-control" style="display:none; margin-top:0.5rem; max-width:200px;" value="2026-08-12">
                <input type="hidden" id="upload-studied-at" value="2026-08-12">
              </div>

              <button class="btn btn-primary" id="btn-upload" style="width:100%; margin-top:1.25rem; padding:0.85rem; font-weight:700;">
                <span class="btn-text">🧠 Processar, Catalogar e Agendar Revisões</span>
                <span class="btn-loading" style="display:none;">⏳ Analisando conteúdo da apostila...</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Materials Library / Subject Catalog -->
      <div class="card" id="catalog-card-container" style="margin-top: 1rem;">
        <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <h3>📚 Catálogo de Aulas por Matéria</h3>
            <p class="text-muted" style="font-size:0.85rem; margin-top:0.25rem;">Histórico e sequência de estudo por disciplina</p>
          </div>
          <button class="btn btn-secondary btn-sm" id="btn-refresh-catalog">🔄 Atualizar</button>
        </div>
        
        <div id="catalog-overview-stats" class="catalog-overview-card" style="display:none;">
          <!-- Dinâmico -->
        </div>

        <div id="materials-list" style="padding: 1rem 0;">
          <div class="loading-placeholder">Carregando catálogo de aulas...</div>
        </div>
      </div>

      <!-- Active Study Session (Split Screen) -->
      <div id="study-session-area" class="study-session-area" style="display:none;">
        <!-- Session Header with Timer -->
        <div class="card study-session-header">
          <div class="session-info">
            <div style="display:flex; align-items:center; gap:0.5rem;">
              <span id="session-lesson-badge" class="lesson-number-badge">Aula --</span>
              <h3 id="session-material-title" style="margin:0;">📖 Estudando: ...</h3>
            </div>
            <p class="text-muted" id="session-material-subject" style="margin-top:0.35rem; font-size:0.9rem;"></p>
          </div>

          <div class="session-timer" id="session-timer">
            <div class="timer-display">
              <span class="timer-icon">⏱️</span>
              <span id="timer-value" class="timer-value">00:00</span>
            </div>
            <div class="timer-bar">
              <div class="timer-bar-fill" id="timer-bar-fill"></div>
            </div>
          </div>

          <div class="session-scope-note" style="flex:1; min-width:260px;">
            <label for="session-scope-note" class="text-muted" style="font-size:0.8rem; display:block; margin-bottom:0.25rem;">
              Até onde você leu? (Opcional — as questões de fixação vão focar neste trecho)
            </label>
            <input type="text" id="session-scope-note" class="form-control"
              placeholder="Ex: li até a pág. 25 / conceito de competência privativa">
          </div>

          <div class="session-actions">
            <button class="btn btn-danger btn-sm" id="btn-finish-session">⏹️ Concluir e Fixar</button>
          </div>
        </div>

        <!-- Session Content: Left (PDF / Summary Tabs) + Right (Chat) -->
        <div class="session-split-container">
          <!-- Left: Tabbed Document Viewer -->
          <div class="card session-viewer-card">
            <div class="study-nav-tabs">
              <button class="study-tab-btn active" id="tab-btn-pdf" data-tab="pdf">
                📄 Apostila Original (PDF)
              </button>
              <button class="study-tab-btn" id="tab-btn-raiox" data-tab="raiox">
                🎯 Raio-X & Foco FGV
              </button>
              <button class="study-tab-btn" id="tab-btn-summary" data-tab="summary">
                📋 Resumo da Aula
              </button>
              <a href="#" id="session-external-pdf" target="_blank" rel="noopener" class="btn btn-secondary btn-sm" style="margin-left:auto; text-decoration:none;">
                ↗️ Abrir em Nova Aba
              </a>
            </div>

            <!-- Panel 1: Embedded PDF Viewer -->
            <div class="session-tab-content" id="panel-pdf">
              <iframe id="pdf-frame" class="pdf-viewer-frame" src="about:blank" title="Visualizador da Apostila"></iframe>
            </div>

            <!-- Panel 2: Raio-X & Foco FGV (Smart Filter) -->
            <div class="session-tab-content session-summary-panel" id="panel-raiox" style="display:none; padding:1rem; overflow-y:auto; max-height:calc(100vh - 300px);">
              <!-- Dinâmico via renderRaioXPanel -->
            </div>

            <!-- Panel 3: Strategic Summary & Topics -->
            <div class="session-tab-content session-summary-panel" id="panel-summary" style="display:none; padding:1rem; overflow-y:auto; max-height:calc(100vh - 300px);">
              <h4 style="margin-bottom:0.75rem;">📋 Resumo Estratégico</h4>
              <div id="session-summary" class="markdown-content"></div>
              <div class="session-topics" id="session-topics" style="margin-top:1.5rem;"></div>
            </div>
          </div>

          <!-- Right: Contextual AI Tutor Chat -->
          <div class="card session-chat-card" style="display:flex; flex-direction:column; height:100%;">
            <div style="border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem; margin-bottom: 0.5rem;">
              <h4 style="margin:0;">💬 Tutor Contextual da Aula</h4>
              <p class="text-muted" style="font-size:0.75rem; margin-top:0.2rem;">Tire dúvidas sobre conceitos, leis e pegadinhas da banca</p>
            </div>
            
            <div class="chat-messages" id="session-chat-messages" style="flex:1; overflow-y:auto;">
              <div class="chat-message model">
                <div class="message-content">
                  Estou com o texto integral desta aula aberto! Qualquer dúvida sobre os conceitos, artigos de lei ou pegadinhas da FGV/Cebraspe, é só me perguntar. 🎓
                </div>
              </div>
            </div>

            <div class="chat-input-area">
              <input type="text" id="session-chat-input" class="form-control" placeholder="Pergunte sobre um conceito da aula...">
              <button class="btn btn-primary" id="btn-session-chat-send">Enviar</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Fixation Questions Area -->
      <div id="fixation-area" class="fixation-area" style="display:none;">
        <div class="card fixation-header">
          <div class="fixation-alert">
            <span class="fixation-icon">⏰</span>
            <div>
              <h3>Hora de Fixar o Conteúdo!</h3>
              <p>Sessão finalizada. Resolva as questões abaixo para consolidar seu aprendizado na memória de longo prazo.</p>
            </div>
          </div>
          <div class="fixation-progress">
            <span id="fixation-progress-text">0 / 0</span>
            <div class="progress-bar">
              <div class="progress-bar-fill" id="fixation-progress-bar"></div>
            </div>
          </div>
        </div>

        <div id="fixation-questions-container"></div>

        <div id="fixation-results" style="display:none;">
          <div class="card fixation-results-card">
            <h3>📊 Resultado da Fixação</h3>
            <div class="fixation-score" id="fixation-score"></div>
            <div class="fixation-details" id="fixation-details"></div>
            <button class="btn btn-primary" id="btn-back-to-materials" style="margin-top:1rem;">← Voltar ao Catálogo de Aulas</button>
          </div>
        </div>
      </div>
    </div>
  `;

  // Initialize
  setupUploadHandlers();
  setupTabHandlers();
  loadCatalog();

  document.getElementById('btn-refresh-catalog')?.addEventListener('click', loadCatalog);
}

// ============================================================
// TAB HANDLERS (PDF vs RAIO-X vs RESUMO)
// ============================================================

function setupTabHandlers() {
  const btnPdf = document.getElementById('tab-btn-pdf');
  const btnRaiox = document.getElementById('tab-btn-raiox');
  const btnSummary = document.getElementById('tab-btn-summary');
  const panelPdf = document.getElementById('panel-pdf');
  const panelRaiox = document.getElementById('panel-raiox');
  const panelSummary = document.getElementById('panel-summary');

  if (!btnPdf || !btnSummary || !btnRaiox) return;

  const showTab = (activeBtn, activePanel) => {
    [btnPdf, btnRaiox, btnSummary].forEach(b => b.classList.remove('active'));
    [panelPdf, panelRaiox, panelSummary].forEach(p => p.style.display = 'none');
    activeBtn.classList.add('active');
    activePanel.style.display = activePanel === panelPdf ? 'flex' : 'block';
  };

  btnPdf.addEventListener('click', () => showTab(btnPdf, panelPdf));
  btnRaiox.addEventListener('click', () => showTab(btnRaiox, panelRaiox));
  btnSummary.addEventListener('click', () => showTab(btnSummary, panelSummary));
}

// ============================================================
// FILE UPLOAD HANDLERS
// ============================================================

let selectedFile = null;

function setupUploadHandlers() {
  const fileInput = document.getElementById('file-input');
  const dropzone = document.getElementById('upload-dropzone');
  const uploadConfig = document.getElementById('upload-config');
  const removeBtn = document.getElementById('upload-remove');
  const uploadBtn = document.getElementById('btn-upload');

  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      selectFile(e.target.files[0]);
    }
  });

  dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('dragover');
  });
  dropzone.addEventListener('dragleave', () => {
    dropzone.classList.remove('dragover');
  });
  dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    if (e.dataTransfer.files.length > 0) {
      selectFile(e.dataTransfer.files[0]);
    }
  });

  removeBtn.addEventListener('click', () => {
    selectedFile = null;
    uploadConfig.style.display = 'none';
    dropzone.style.display = 'flex';
    fileInput.value = '';
  });

  // Date Quick Selection in Upload
  document.querySelectorAll('#upload-date-quick-btns .date-pill-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#upload-date-quick-btns .date-pill-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const dateVal = btn.dataset.date;
      const customInput = document.getElementById('upload-custom-date');
      const hiddenInput = document.getElementById('upload-studied-at');
      if (dateVal === 'custom') {
        customInput.style.display = 'block';
        hiddenInput.value = customInput.value;
      } else {
        customInput.style.display = 'none';
        hiddenInput.value = dateVal;
      }
    });
  });

  document.getElementById('upload-custom-date')?.addEventListener('change', (e) => {
    document.getElementById('upload-studied-at').value = e.target.value;
  });

  uploadBtn.addEventListener('click', uploadAndAnalyze);
}

function selectFile(file) {
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    showToast('Apenas arquivos PDF são aceitos.', 'error');
    return;
  }

  selectedFile = file;
  document.getElementById('upload-filename').textContent = file.name;
  document.getElementById('upload-dropzone').style.display = 'none';
  document.getElementById('upload-config').style.display = 'block';
}

async function uploadAndAnalyze() {
  if (!selectedFile) return;

  const btn = document.getElementById('btn-upload');
  const btnText = btn.querySelector('.btn-text');
  const btnLoading = btn.querySelector('.btn-loading');

  btn.disabled = true;
  btnText.style.display = 'none';
  btnLoading.style.display = 'inline';

  try {
    const formData = new FormData();
    formData.append('pdf', selectedFile);
    formData.append('subject', document.getElementById('upload-subject').value);
    formData.append('studiedAt', document.getElementById('upload-studied-at').value);
    formData.append('studyStatus', document.getElementById('upload-study-status').value);

    const response = await fetch('/api/study-room/upload', {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'Falha no upload');
    }

    const data = await response.json();
    const lessonLabel = data.lessonNumber !== null ? `Aula ${data.lessonNumber}` : 'Aula';
    showToast(`✅ ${data.subject} (${lessonLabel}) catalogada e revisões agendadas!`, 'success');

    // Reset upload area
    selectedFile = null;
    document.getElementById('upload-config').style.display = 'none';
    document.getElementById('upload-dropzone').style.display = 'flex';
    document.getElementById('file-input').value = '';

    // Reload catalog
    loadCatalog();

  } catch (error) {
    console.error('Upload error:', error);
    showToast(error.message || 'Erro ao processar o material.', 'error');
  } finally {
    btn.disabled = false;
    btnText.style.display = 'inline';
    btnLoading.style.display = 'none';
  }
}

// ============================================================
// CATALOG BY SUBJECT
// ============================================================

async function loadCatalog() {
  const container = document.getElementById('materials-list');
  const statsContainer = document.getElementById('catalog-overview-stats');

  try {
    const response = await fetch('/api/study-room/catalog');
    if (!response.ok) throw new Error('Falha ao obter catálogo');

    const data = await response.json();
    const catalog = data.catalog || [];

    if (catalog.length === 0) {
      statsContainer.style.display = 'none';
      container.innerHTML = `
        <div class="empty-state">
          <span class="empty-icon">📂</span>
          <p>Nenhuma aula catalogada ainda. Faça upload do seu primeiro PDF ou importe do Google Drive!</p>
        </div>
      `;
      return;
    }

    // Render Stats
    let totalMaterias = catalog.length;
    let totalAulas = 0;
    let totalConcluidas = 0;

    catalog.forEach(cat => {
      totalAulas += cat.totalAulas;
      totalConcluidas += cat.concluidas;
    });

    const percent = totalAulas > 0 ? Math.round((totalConcluidas / totalAulas) * 100) : 0;

    statsContainer.style.display = 'grid';
    statsContainer.innerHTML = `
      <div class="stat-pill">
        <span class="stat-pill-label">Disciplinas Ativas</span>
        <span class="stat-pill-val">${totalMaterias}</span>
      </div>
      <div class="stat-pill">
        <span class="stat-pill-label">Total de Aulas</span>
        <span class="stat-pill-val">${totalAulas}</span>
      </div>
      <div class="stat-pill">
        <span class="stat-pill-label">Aulas Estudadas</span>
        <span class="stat-pill-val" style="color:#34D399;">${totalConcluidas}</span>
      </div>
      <div class="stat-pill">
        <span class="stat-pill-label">Progresso Geral</span>
        <span class="stat-pill-val" style="color:#60A5FA;">${percent}%</span>
      </div>
    `;

    // Render Subjects
    container.innerHTML = catalog.map(cat => {
      const subjectColor = getSubjectColor(cat.subject);
      const waveLabel = cat.wave ? `Wave ${cat.wave}` : '';
      const questionsLabel = cat.weightQuestions ? `${cat.weightQuestions} questões na prova` : '';

      return `
        <div class="subject-catalog-group">
          <div class="subject-catalog-header">
            <div class="subject-catalog-title">
              <span class="badge badge-${subjectColor}">${cat.subject}</span>
              ${waveLabel ? `<span class="badge badge-secondary" style="font-size:0.75rem;">${waveLabel}</span>` : ''}
              <span>${cat.aulas.length > 0 ? `${cat.aulas.length} aula(s) carregada(s)` : 'Disciplina Mapeada'}</span>
            </div>
            <div class="subject-catalog-meta">
              <span class="text-muted" style="font-size:0.85rem;">
                ${cat.aulas.length > 0 ? `${cat.concluidas}/${cat.totalAulas} estudadas` : questionsLabel}
              </span>
            </div>
          </div>

          <div class="subject-lessons-list">
            ${cat.aulas.length > 0 ? cat.aulas.map(aula => {
              const lessonNum = aula.lesson_number !== null ? `Aula ${String(aula.lesson_number).padStart(2, '0')}` : 'Tema';
              
              let statusPill = '';
              if (aula.theory_completed === 1 && (aula.questions_completed === 1 || aula.session_count > 0)) {
                statusPill = `<span class="lesson-status-pill lesson-status-completed">✅ Teoria + Questões Feitas ${aula.studied_at ? '(' + formatDate(aula.studied_at) + ')' : ''}</span>`;
              } else if (aula.theory_completed === 1) {
                statusPill = `<span class="lesson-status-pill" style="background:rgba(245,158,11,0.15); color:#FBBF24; border:1px solid #F59E0B;">⚠️ Apenas Teoria Lida (${formatDate(aula.studied_at)})</span>`;
              } else {
                statusPill = `<span class="lesson-status-pill lesson-status-pending">⚪ Não iniciada</span>`;
              }

              // Reviews Badges
              const reviews = aula.reviews || [];
              let reviewsHtml = '';
              if (reviews.length > 0) {
                const todayStr = new Date().toISOString().split('T')[0];
                reviewsHtml = `
                  <div style="display:flex; gap:0.35rem; margin-top:0.35rem; flex-wrap:wrap; align-items:center;">
                    <span style="font-size:0.72rem; color:var(--text-muted);">Revisões:</span>
                    ${reviews.map(r => {
                      const isOverdue = r.scheduled_date < todayStr;
                      const isToday = r.scheduled_date === todayStr;
                      const badgeClass = isOverdue ? 'badge-danger' : (isToday ? 'badge-primary' : 'badge-secondary');
                      const label = r.review_type.toUpperCase();
                      return `<span class="badge ${badgeClass}" style="font-size:0.7rem;" title="${label}: ${formatDate(r.scheduled_date)}">${label}: ${formatDate(r.scheduled_date)} ${isOverdue ? '⚠️' : ''}</span>`;
                    }).join('')}
                  </div>
                `;
              }

              return `
                <div class="lesson-item-row" data-id="${aula.id}">
                  <div style="display:flex; align-items:center; flex:1; min-width:0;">
                    <span class="lesson-number-badge">${lessonNum}</span>
                    <div class="lesson-title-area" style="flex:1; min-width:0;">
                      <span class="lesson-title-text">${aula.title || aula.filename}</span>
                      <div class="lesson-sub-meta">
                        ${statusPill}
                        <span>📖 ${aula.session_count || 0} sessões</span>
                      </div>
                      ${reviewsHtml}
                    </div>
                  </div>

                  <div style="display:flex; gap:0.4rem; align-items:center; flex-wrap:wrap;">
                    <button class="btn btn-primary btn-sm btn-start-study" data-id="${aula.id}">
                      ${aula.isCompleted ? '🔄 Revisar' : '▶️ Estudar'}
                    </button>
                    <button class="btn btn-secondary btn-sm btn-edit-status" data-id="${aula.id}" 
                      data-subject="${cat.subject}" 
                      data-lesson="${aula.lesson_number || ''}" 
                      data-date="${aula.studied_at || ''}"
                      data-theory="${aula.theory_completed || 0}"
                      data-questions="${aula.questions_completed || 0}"
                      title="Alterar data real de estudo e reagendar revisões">
                      📅 Data
                    </button>
                    <button class="btn btn-danger btn-sm btn-delete-material" data-id="${aula.id}" title="Excluir aula">
                      🗑️
                    </button>
                  </div>
                </div>
              `;
            }).join('') : `
              <div class="lesson-item-row" style="opacity:0.85; border:1px dashed var(--glass-border);">
                <div style="display:flex; align-items:center; flex:1;">
                  <span class="lesson-number-badge" style="background:var(--bg-secondary); color:var(--text-muted);">Aula 01</span>
                  <div class="lesson-title-area">
                    <span class="lesson-title-text" style="color:var(--text-secondary);">${cat.description || 'Apostila ainda não enviada'}</span>
                    <div class="lesson-sub-meta">
                      <span class="lesson-status-pill lesson-status-pending">⚪ Aguardando upload da Aula 01</span>
                    </div>
                  </div>
                </div>
                <button class="btn btn-secondary btn-sm" onclick="document.getElementById('upload-subject').value='${cat.subject}'; document.getElementById('file-input').click();">
                  📤 Enviar Apostila
                </button>
              </div>
            `}
          </div>
        </div>
      `;
    }).join('');

    // Event listeners
    container.querySelectorAll('.btn-start-study').forEach(btn => {
      btn.addEventListener('click', () => showStartSessionDialog(btn.dataset.id));
    });

    container.querySelectorAll('.btn-edit-status').forEach(btn => {
      btn.addEventListener('click', () => {
        showEditStudyStatusModal(
          btn.dataset.id,
          btn.dataset.subject,
          btn.dataset.lesson,
          btn.dataset.date,
          btn.dataset.theory,
          btn.dataset.questions
        );
      });
    });

    container.querySelectorAll('.btn-delete-material').forEach(btn => {
      btn.addEventListener('click', () => deleteMaterial(btn.dataset.id));
    });

  } catch (error) {
    console.error('Erro ao carregar catálogo:', error);
    container.innerHTML = `
      <div class="empty-state">
        <span class="empty-icon">⚠️</span>
        <p>Erro ao carregar catálogo. Clique em Atualizar para tentar novamente.</p>
      </div>
    `;
  }
}

// Modal de alteração retroativa de data e status
function showEditStudyStatusModal(materialId, subject, lessonNumber, currentDate, theoryCompleted, questionsCompleted) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  
  let defaultStatus = 'theory_only';
  if (parseInt(theoryCompleted, 10) === 1 && parseInt(questionsCompleted, 10) === 1) defaultStatus = 'full';
  else if (parseInt(theoryCompleted, 10) === 0) defaultStatus = 'unread';

  const defaultDate = currentDate || '2026-08-12';

  overlay.innerHTML = `
    <div class="modal card" style="max-width:480px;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem; border-bottom:1px solid var(--glass-border); padding-bottom:0.5rem;">
        <h3 style="margin:0; font-size:1.15rem;">📅 Data Real de Estudo & Revisões</h3>
        <button class="btn-icon" id="btn-close-edit-modal" style="cursor:pointer;">✕</button>
      </div>

      <div style="margin-bottom:1rem;">
        <span class="badge badge-primary">${subject}</span>
        <strong style="margin-left:0.5rem;">Aula ${lessonNumber || 'Pendente'}</strong>
      </div>

      <div class="form-group">
        <label style="font-weight:600;">Status do Estudo</label>
        <select id="edit-study-status" class="form-control">
          <option value="theory_only" ${defaultStatus === 'theory_only' ? 'selected' : ''}>⚠️ Apenas Teoria Lida (Revisão & Questões na Fila)</option>
          <option value="full" ${defaultStatus === 'full' ? 'selected' : ''}>✅ Completo (Teoria Lida + Questões Feitas)</option>
          <option value="unread" ${defaultStatus === 'unread' ? 'selected' : ''}>⚪ Não estudada (Zerar status)</option>
        </select>
      </div>

      <div class="form-group" style="margin-top:0.75rem;">
        <label style="font-weight:600; display:flex; justify-content:space-between;">
          <span>Data Real em que foi Estudada:</span>
        </label>
        <div style="display:flex; gap:0.4rem; flex-wrap:wrap; margin-top:0.35rem;" id="modal-date-quick-btns">
          <button type="button" class="btn btn-secondary btn-sm date-modal-pill" data-date="2026-08-10">⏮️ Segunda (10/08)</button>
          <button type="button" class="btn btn-secondary btn-sm date-modal-pill" data-date="2026-08-11">⏮️ Ontem (11/08)</button>
          <button type="button" class="btn btn-secondary btn-sm date-modal-pill active" data-date="2026-08-12">⭐ Hoje (12/08)</button>
        </div>
        <input type="date" id="modal-studied-at" class="form-control" style="margin-top:0.5rem;" value="${defaultDate}">
      </div>

      <div class="modal-actions" style="margin-top:1.5rem; display:flex; justify-content:flex-end; gap:0.5rem;">
        <button class="btn btn-secondary" id="btn-cancel-edit-modal">Cancelar</button>
        <button class="btn btn-primary" id="btn-save-edit-modal">💾 Salvar & Reagendar Revisões</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  overlay.querySelector('#btn-close-edit-modal').onclick = () => overlay.remove();
  overlay.querySelector('#btn-cancel-edit-modal').onclick = () => overlay.remove();

  overlay.querySelectorAll('.date-modal-pill').forEach(btn => {
    btn.onclick = () => {
      overlay.querySelectorAll('.date-modal-pill').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      overlay.querySelector('#modal-studied-at').value = btn.dataset.date;
    };
  });

  overlay.querySelector('#btn-save-edit-modal').onclick = async () => {
    const studyStatus = overlay.querySelector('#edit-study-status').value;
    const studiedAt = overlay.querySelector('#modal-studied-at').value;

    try {
      const res = await fetch(`/api/study-room/materials/${materialId}/study-status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studyStatus, studiedAt })
      });

      if (res.ok) {
        showToast('Data e ciclo de revisões atualizados com sucesso! 🧠🎯', 'success');
        overlay.remove();
        loadCatalog();
      } else {
        showToast('Erro ao atualizar status.', 'error');
      }
    } catch (e) {
      showToast('Erro ao conectar com o servidor.', 'error');
    }
  };
}

async function deleteMaterial(id) {
  if (!confirm('Deseja realmente excluir este material e o histórico de sessões associado?')) return;

  try {
    const response = await fetch(`/api/study-room/materials/${id}`, { method: 'DELETE' });
    if (response.ok) {
      showToast('Material removido com sucesso.', 'success');
      loadCatalog();
    } else {
      showToast('Erro ao remover material.', 'error');
    }
  } catch (e) {
    showToast('Erro ao remover material.', 'error');
  }
}

// ============================================================
// STUDY SESSION
// ============================================================

function showStartSessionDialog(materialId) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal card">
      <h3>⏱️ Definir Tempo de Estudo da Aula</h3>
      <p class="text-muted">Quanto tempo você vai focar na leitura e fixação desta aula?</p>
      <div class="duration-options">
        <button class="btn btn-option duration-btn" data-minutes="25">25 min (Pomodoro)</button>
        <button class="btn btn-option duration-btn" data-minutes="45">45 min</button>
        <button class="btn btn-option duration-btn active" data-minutes="60">1 hora (Recomendado)</button>
        <button class="btn btn-option duration-btn" data-minutes="90">1h30</button>
        <button class="btn btn-option duration-btn" data-minutes="120">2 horas</button>
      </div>
      <div class="form-group" style="margin-top: 1rem;">
        <label>Ou tempo personalizado (minutos):</label>
        <input type="number" id="custom-duration" class="form-control" min="5" max="480" placeholder="Ex: 50">
      </div>
      <div class="modal-actions">
        <button class="btn btn-secondary" id="btn-cancel-session">Cancelar</button>
        <button class="btn btn-primary" id="btn-confirm-session">📚 Iniciar Estudo da Aula</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  let selectedMinutes = 60;

  overlay.querySelectorAll('.duration-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      overlay.querySelectorAll('.duration-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedMinutes = parseInt(btn.dataset.minutes);
      document.getElementById('custom-duration').value = '';
    });
  });

  document.getElementById('custom-duration').addEventListener('input', (e) => {
    if (e.target.value) {
      selectedMinutes = parseInt(e.target.value);
      overlay.querySelectorAll('.duration-btn').forEach(b => b.classList.remove('active'));
    }
  });

  document.getElementById('btn-cancel-session').addEventListener('click', () => overlay.remove());

  document.getElementById('btn-confirm-session').addEventListener('click', () => {
    overlay.remove();
    startStudySession(materialId, selectedMinutes);
  });
}

async function startStudySession(materialId, durationMinutes) {
  try {
    const response = await fetch('/api/study-room/sessions/start', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ materialId, durationMinutes })
    });

    if (!response.ok) throw new Error('Falha ao iniciar sessão');
    const sessionData = await response.json();

    const matRes = await fetch(`/api/study-room/materials/${materialId}`);
    const materialData = matRes.ok ? await matRes.json() : null;

    currentSession = {
      ...sessionData,
      durationMinutes,
      material: materialData?.material || { title: 'Aula', summary: '' },
      startTime: Date.now()
    };

    showSessionUI();
    startTimer(durationMinutes);

    showToast(`📚 Sessão de ${durationMinutes} min iniciada! Bom estudo!`, 'success');
  } catch (error) {
    console.error('Erro ao iniciar sessão:', error);
    showToast('Erro ao iniciar sessão.', 'error');
  }
}

function showSessionUI() {
  document.querySelector('.study-room-top').style.display = 'none';
  document.getElementById('catalog-card-container').style.display = 'none';
  document.getElementById('study-session-area').style.display = 'block';
  document.getElementById('fixation-area').style.display = 'none';

  const material = currentSession.material;
  const lessonNum = material.lesson_number !== null ? `Aula ${String(material.lesson_number).padStart(2, '0')}` : 'Aula';

  document.getElementById('session-lesson-badge').textContent = lessonNum;
  document.getElementById('session-material-title').textContent = material.title || material.filename;
  document.getElementById('session-material-subject').textContent = `${material.subject || 'Geral'} • Receita Federal (ATRFB)`;

  // Load PDF in iframe
  const pdfFrame = document.getElementById('pdf-frame');
  const externalLink = document.getElementById('session-external-pdf');
  const pdfUrl = currentSession.pdfUrl || material.pdfUrl;

  if (pdfUrl) {
    pdfFrame.src = pdfUrl;
    externalLink.href = pdfUrl;
    externalLink.style.display = 'inline-flex';
  } else {
    pdfFrame.src = 'about:blank';
    externalLink.style.display = 'none';
  }

  // Activate PDF tab by default
  document.getElementById('tab-btn-pdf').click();

  // Render Raio-X & Foco FGV Panel
  const raioxEl = document.getElementById('panel-raiox');
  const analysis = material.analysis || (material.analysis_json ? JSON.parse(material.analysis_json) : {});
  
  if (raioxEl) {
    const topicosQuentes = analysis.topicosQuentes || [
      'Conceito e Elementos de Tributo (Art. 3º do CTN) — Alta cobrança em casos práticos',
      'Teoria Pentapartida (STF) vs Teoria Tripartida (CTN)',
      'Taxas vs Preços Públicos (Súmula Vinculante 19 e 41)'
    ];
    const topicosIsca = analysis.topicosIsca || [
      'Evolução histórica das receitas públicas na antiguidade (<3% na FGV)',
      'Teorias doutrinárias minoritárias sobre a parafiscalidade'
    ];
    const roteiro = analysis.roteiroLeitura || 'Inicie direto no Art. 3º do CTN e foque na diferença entre Taxas e Tarifas. Pule a introdução histórica inicial.';
    const artigos = analysis.artigosLei || ['Art. 3º do CTN', 'Art. 118 do CTN (Pecunia non olet)', 'Art. 145, II da CF/88 (Taxas)', 'Súmula Vinculante 19', 'Súmula Vinculante 41'];

    raioxEl.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem; padding-bottom:0.75rem; border-bottom:1px solid var(--border-color); flex-wrap:wrap; gap:0.5rem;">
        <div>
          <h4 style="margin:0; font-size:1.1rem; color:var(--text-primary);">🎯 Raio-X & Foco FGV</h4>
          <p class="text-muted" style="font-size:0.8rem; margin:0.2rem 0 0 0;">Filtre a palha e estude apenas o que a banca cobra</p>
        </div>
        <button class="btn btn-primary btn-sm" id="btn-open-caderno-enxuto" style="font-weight:700;">
          ⚡ Caderno Enxuto FGV (Ler em 20 min)
        </button>
      </div>

      <div style="background:var(--color-primary-bg); border-left:4px solid var(--color-primary); padding:0.85rem 1rem; border-radius:var(--radius-sm); margin-bottom:1rem;">
        <div style="font-weight:700; color:var(--color-primary); display:flex; align-items:center; gap:0.4rem;">
          <span>🧭 Roteiro Estratégico de Leitura da Aula</span>
        </div>
        <p style="margin:0.25rem 0 0 0; font-size:0.85rem; color:var(--text-primary); font-weight:500;">
          ${roteiro}
        </p>
      </div>

      <div style="margin-bottom:1rem;">
        <h5 style="color:var(--color-danger); display:flex; align-items:center; gap:0.4rem; margin-bottom:0.4rem; font-size:0.9rem;">
          <span>🔥 O que Sempre Cai na FGV nesta Aula (>75%)</span>
        </h5>
        <div style="display:flex; flex-direction:column; gap:0.4rem;">
          ${topicosQuentes.map(t => `
            <div style="background:var(--bg-tertiary); padding:0.6rem 0.85rem; border-radius:4px; border-left:3px solid var(--color-danger); font-size:0.85rem; color:var(--text-primary);">
              <strong>${t}</strong>
            </div>
          `).join('')}
        </div>
      </div>

      <div style="margin-bottom:1rem;">
        <h5 style="color:var(--text-muted); display:flex; align-items:center; gap:0.4rem; margin-bottom:0.4rem; font-size:0.9rem;">
          <span>🧊 Tópicos Isca (<15% na FGV — Leia rápido ou pule)</span>
        </h5>
        <div style="display:flex; flex-direction:column; gap:0.4rem;">
          ${topicosIsca.map(t => `
            <div style="background:var(--bg-tertiary); padding:0.5rem 0.85rem; border-radius:4px; border-left:3px solid var(--text-muted); font-size:0.82rem; color:var(--text-secondary); opacity:0.85;">
              ⚠️ ${t}
            </div>
          `).join('')}
        </div>
      </div>

      <div style="margin-bottom:1rem;">
        <h5 style="color:var(--color-warning); display:flex; align-items:center; gap:0.4rem; margin-bottom:0.4rem; font-size:0.9rem;">
          <span>⚖️ Artigos de Lei & Súmulas Obrigatórias para Grifar no PDF</span>
        </h5>
        <div class="artigos-tag-list" style="display:flex; flex-wrap:wrap; gap:0.35rem; margin-top:0.4rem;">
          ${artigos.map(a => `<span class="artigo-tag" style="background:var(--color-warning-bg); border:1px solid var(--color-warning); color:var(--color-warning); font-weight:700; padding:0.2rem 0.5rem; border-radius:4px; font-size:0.75rem;">📖 ${a}</span>`).join('')}
        </div>
      </div>
    `;

    document.getElementById('btn-open-caderno-enxuto')?.addEventListener('click', () => {
      openCadernoEnxuto(material.id);
    });
  }

  // Render summary panel (optional tab)
  const summaryEl = document.getElementById('session-summary');
  summaryEl.innerHTML = renderMarkdown(material.summary || analysis.resumoEstrategico || 'Resumo não disponível.');

  const topicsEl = document.getElementById('session-topics');
  const topicos = analysis.topicos || [];
  if (topicos.length > 0) {
    topicsEl.innerHTML = `
      <h5>📌 Tópicos Abordados nesta Aula</h5>
      <div class="topics-list">
        ${topicos.map(t => `
          <div class="topic-item">
            <strong>${t.nome}</strong>
            ${t.subtopicos ? `<ul>${t.subtopicos.map(s => `<li>${s}</li>`).join('')}</ul>` : ''}
          </div>
        `).join('')}
      </div>
    `;
  } else {
    topicsEl.innerHTML = '';
  }

  // Setup contextual chat
  setupSessionChat();

  // Finish session handler
  document.getElementById('btn-finish-session').onclick = finishSession;
}

// ============================================================
// TIMER
// ============================================================

function startTimer(minutes) {
  if (timerInterval) clearInterval(timerInterval);
  remainingSeconds = minutes * 60;
  const totalSeconds = remainingSeconds;
  timerAudioPlayed = false;

  updateTimerDisplay();

  timerInterval = setInterval(() => {
    remainingSeconds--;

    if (remainingSeconds <= 0) {
      clearInterval(timerInterval);
      timerInterval = null;
      onTimerExpired();
      return;
    }

    if (remainingSeconds === 300 && !timerAudioPlayed) {
      timerAudioPlayed = true;
      showToast('⏰ Faltam 5 minutos! Prepare-se para as questões de fixação.', 'warning');
    }

    updateTimerDisplay();

    const progress = ((totalSeconds - remainingSeconds) / totalSeconds) * 100;
    const bar = document.getElementById('timer-bar-fill');
    if (bar) bar.style.width = `${progress}%`;
  }, 1000);
}

function updateTimerDisplay() {
  const hours = Math.floor(remainingSeconds / 3600);
  const minutes = Math.floor((remainingSeconds % 3600) / 60);
  const seconds = remainingSeconds % 60;

  const display = hours > 0
    ? `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
    : `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  const valEl = document.getElementById('timer-value');
  if (valEl) valEl.textContent = display;

  const timerEl = document.getElementById('session-timer');
  if (timerEl) {
    if (remainingSeconds <= 60) {
      timerEl.classList.add('timer-critical');
    } else if (remainingSeconds <= 300) {
      timerEl.classList.add('timer-warning');
    }
  }
}

function onTimerExpired() {
  showToast('⏰ Tempo esgotado! Gerando questões de fixação...', 'info');
  finishSession();
}

// ============================================================
// SESSION CONTEXTUAL CHAT
// ============================================================

function setupSessionChat() {
  const input = document.getElementById('session-chat-input');
  const sendBtn = document.getElementById('btn-session-chat-send');

  const send = () => {
    const message = input.value.trim();
    if (!message) return;
    input.value = '';
    sendSessionMessage(message);
  };

  sendBtn.onclick = send;
  input.onkeydown = (e) => {
    if (e.key === 'Enter') send();
  };
}

async function sendSessionMessage(message) {
  const container = document.getElementById('session-chat-messages');

  const userDiv = document.createElement('div');
  userDiv.className = 'chat-message user';
  userDiv.innerHTML = `<div class="message-content">${message}</div>`;
  container.appendChild(userDiv);

  const modelDiv = document.createElement('div');
  modelDiv.className = 'chat-message model';
  modelDiv.innerHTML = `<div class="message-content"><span class="typing-indicator">●●●</span></div>`;
  container.appendChild(modelDiv);
  container.scrollTop = container.scrollHeight;

  try {
    const response = await fetch(`/api/study-room/sessions/${currentSession.sessionId}/ask`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message })
    });

    if (response.headers.get('Content-Type')?.includes('text/event-stream')) {
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullText = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.substring(6));
              if (data.done) break;
              if (data.chunk) {
                fullText += data.chunk;
                modelDiv.querySelector('.message-content').innerHTML = renderMarkdown(fullText);
                container.scrollTop = container.scrollHeight;
              }
            } catch (e) {}
          }
        }
      }
    } else {
      const data = await response.json();
      modelDiv.querySelector('.message-content').innerHTML = renderMarkdown(data.response || 'Erro ao processar');
    }
  } catch (error) {
    console.error('Chat error:', error);
    modelDiv.querySelector('.message-content').innerHTML = '❌ Erro ao enviar mensagem.';
  }
}

// ============================================================
// CADERNO ENXUTO FGV (SMART FILTER)
// ============================================================

async function openCadernoEnxuto(materialId) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal card" style="max-width:760px; max-height:85vh; display:flex; flex-direction:column;">
      <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border-color); padding-bottom:0.75rem; margin-bottom:1rem;">
        <div style="display:flex; align-items:center; gap:0.5rem;">
          <span style="font-size:1.4rem;">⚡</span>
          <div>
            <h3 style="margin:0; font-size:1.15rem; color:var(--text-primary);">Caderno Enxuto FGV (Leitura Rápida)</h3>
            <p class="text-muted" style="margin:0; font-size:0.78rem;">Palha teórica e tópicos isca eliminados — apenas o núcleo de prova</p>
          </div>
        </div>
        <button class="btn-icon" id="btn-close-caderno" style="cursor:pointer;">✕</button>
      </div>

      <div id="caderno-body" style="flex:1; overflow-y:auto; padding:0.5rem; line-height:1.6;">
        <div class="loading-placeholder">🧠 Analisando a apostila, descartando partes irrelevantes e estruturando o Caderno Enxuto FGV...</div>
      </div>

      <div class="modal-actions" style="margin-top:1rem; padding-top:0.75rem; border-top:1px solid var(--border-color); display:flex; justify-content:space-between;">
        <button class="btn btn-secondary btn-sm" id="btn-copy-caderno">📋 Copiar Texto</button>
        <div style="display:flex; gap:0.5rem;">
          <button class="btn btn-secondary btn-sm" id="btn-regerar-caderno">🔄 Re-gerar Filtro</button>
          <button class="btn btn-primary btn-sm" id="btn-ok-caderno">Concluir Leitura</button>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  overlay.querySelector('#btn-close-caderno').onclick = () => overlay.remove();
  overlay.querySelector('#btn-ok-caderno').onclick = () => overlay.remove();

  let currentText = '';

  const loadCaderno = async (force = false) => {
    const bodyEl = overlay.querySelector('#caderno-body');
    bodyEl.innerHTML = `<div class="loading-placeholder">🧠 Analisando a apostila, descartando partes irrelevantes e estruturando o Caderno Enxuto FGV...</div>`;

    try {
      const res = await fetch(`/api/study-room/materials/${materialId}/caderno-enxuto`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ force })
      });

      if (!res.ok) throw new Error('Falha ao processar Caderno Enxuto.');
      const data = await res.json();
      currentText = data.cadernoEnxuto || 'Não foi possível extrair o caderno enxuto.';

      bodyEl.innerHTML = `
        <div class="markdown-content" style="font-size:0.92rem;">
          ${renderMarkdown(currentText)}
        </div>
      `;
    } catch (e) {
      bodyEl.innerHTML = `<p class="text-muted">❌ ${e.message || 'Erro ao carregar o Caderno Enxuto.'}</p>`;
    }
  };

  overlay.querySelector('#btn-regerar-caderno').onclick = () => loadCaderno(true);
  overlay.querySelector('#btn-copy-caderno').onclick = () => {
    if (currentText) {
      navigator.clipboard.writeText(currentText);
      showToast('Caderno Enxuto copiado para a área de transferência!', 'success');
    }
  };

  loadCaderno();
}

// ============================================================
// FINISH SESSION & FIXATION QUESTIONS
// ============================================================

function finishSession() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }

  const scopeNote = document.getElementById('session-scope-note')?.value || '';
  const actualDuration = currentSession.durationMinutes * 60 - remainingSeconds;

  // Mode Selection Modal
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal card" style="max-width:500px;">
      <div style="border-bottom:1px solid var(--border-color); padding-bottom:0.5rem; margin-bottom:1rem;">
        <h3 style="margin:0; font-size:1.15rem; color:var(--text-primary);">🎯 Concluir Estudo & Calibrar Fixação</h3>
        <p class="text-muted" style="margin:0.25rem 0 0 0; font-size:0.8rem;">Escolha o foco da bateria de questões gerada pela IA:</p>
      </div>

      <div style="display:flex; flex-direction:column; gap:0.6rem; margin-bottom:1.25rem;">
        <label style="padding:0.75rem 1rem; border:1px solid var(--border-color); border-radius:var(--radius-sm); cursor:pointer; display:flex; align-items:flex-start; gap:0.75rem; background:var(--bg-tertiary);">
          <input type="radio" name="fixation-mode-choice" value="sempre_cai" checked style="margin-top:0.2rem;">
          <div>
            <strong style="color:var(--text-primary); font-size:0.9rem;">🔥 Modo "Sempre Cai" (>75% na FGV) — 10 Questões</strong>
            <p style="margin:0.15rem 0 0 0; font-size:0.78rem; color:var(--text-secondary);">Foca no núcleo duro e regras essenciais que mais pontuam na prova.</p>
          </div>
        </label>

        <label style="padding:0.75rem 1rem; border:1px solid var(--border-color); border-radius:var(--radius-sm); cursor:pointer; display:flex; align-items:flex-start; gap:0.75rem; background:var(--bg-tertiary);">
          <input type="radio" name="fixation-mode-choice" value="armadilhas" style="margin-top:0.2rem;">
          <div>
            <strong style="color:var(--color-danger); font-size:0.9rem;">⚠️ Modo "Pegadinhas & Armadilhas FGV" — 5 Questões</strong>
            <p style="margin:0.15rem 0 0 0; font-size:0.78rem; color:var(--text-secondary);">Casos práticos com as trocas de conceitos clássicas da banca examinadora.</p>
          </div>
        </label>

        <label style="padding:0.75rem 1rem; border:1px solid var(--border-color); border-radius:var(--radius-sm); cursor:pointer; display:flex; align-items:flex-start; gap:0.75rem; background:var(--bg-tertiary);">
          <input type="radio" name="fixation-mode-choice" value="tendencias" style="margin-top:0.2rem;">
          <div>
            <strong style="color:var(--color-primary); font-size:0.9rem;">📈 Modo "Tendências Recentes 2024-2026" — 5 Questões</strong>
            <p style="margin:0.15rem 0 0 0; font-size:0.78rem; color:var(--text-secondary);">Reformas recentes e jurisprudência pacificada do STF/STJ.</p>
          </div>
        </label>
      </div>

      <div class="modal-actions" style="display:flex; justify-content:flex-end; gap:0.5rem;">
        <button class="btn btn-secondary" id="btn-cancel-finish-dialog">Voltar à Leitura</button>
        <button class="btn btn-primary" id="btn-confirm-finish-dialog">Gerar Questões & Fixar 🚀</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  overlay.querySelector('#btn-cancel-finish-dialog').onclick = () => overlay.remove();

  overlay.querySelector('#btn-confirm-finish-dialog').onclick = async () => {
    const selectedMode = overlay.querySelector('input[name="fixation-mode-choice"]:checked')?.value || 'sempre_cai';
    overlay.remove();

    showToast('⏳ Gerando questões calibradas no padrão FGV...', 'info');

    try {
      const response = await fetch(`/api/study-room/sessions/${currentSession.sessionId}/finish`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          actualDurationSeconds: Math.max(0, actualDuration),
          scopeNote,
          mode: selectedMode,
          questionCount: selectedMode === 'sempre_cai' ? 10 : 5
        })
      });

      if (!response.ok) throw new Error('Falha ao gerar questões de fixação');
      const data = await response.json();

      document.getElementById('study-session-area').style.display = 'none';
      document.getElementById('fixation-area').style.display = 'block';

      renderFixationQuestions(data.questions || []);

    } catch (error) {
      console.error('Finish session error:', error);
      showToast('Erro ao gerar questões de fixação.', 'error');
    }
  };
}

let fixationAnswers = {};
let fixationQuestionsList = [];

function renderFixationQuestions(questions) {
  fixationQuestionsList = questions;
  fixationAnswers = {};

  const container = document.getElementById('fixation-questions-container');
  const progressText = document.getElementById('fixation-progress-text');
  const progressBar = document.getElementById('fixation-progress-bar');
  const resultsDiv = document.getElementById('fixation-results');

  resultsDiv.style.display = 'none';
  progressText.textContent = `0 / ${questions.length}`;
  progressBar.style.width = '0%';

  if (questions.length === 0) {
    container.innerHTML = `<p class="text-muted">Nenhuma questão gerada.</p>`;
    return;
  }

  container.innerHTML = questions.map((q, idx) => `
    <div class="card question-card" id="fixation-q-${q.id}" style="margin-bottom: 1rem;">
      <div class="question-meta">
        <span class="badge badge-info">Questão ${idx + 1}/${questions.length}</span>
        <span class="badge badge-${q.difficulty === 'facil' ? 'success' : q.difficulty === 'dificil' ? 'danger' : 'warning'}">
          ${q.difficulty || 'médio'}
        </span>
        ${q.topic ? `<span class="badge badge-secondary">${q.topic}</span>` : ''}
      </div>

      <div class="question-text">${q.question}</div>

      <div class="question-options">
        ${q.options.map((opt, optIdx) => {
          const letter = String.fromCharCode(65 + optIdx);
          return `
            <button class="question-option" data-qid="${q.id}" data-opt="${optIdx}">
              <span class="option-letter">${letter}</span>
              <span class="option-text">${opt}</span>
            </button>
          `;
        }).join('')}
      </div>

      <div class="question-feedback" id="feedback-${q.id}" style="display:none; margin-top:1rem; padding:1rem; border-radius:var(--radius-sm);"></div>
    </div>
  `).join('');

  container.querySelectorAll('.question-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const qid = parseInt(btn.dataset.qid);
      const opt = parseInt(btn.dataset.opt);
      answerFixationQuestion(qid, opt);
    });
  });

  document.getElementById('btn-back-to-materials').onclick = () => {
    document.getElementById('fixation-area').style.display = 'none';
    document.querySelector('.study-room-top').style.display = 'block';
    document.getElementById('catalog-card-container').style.display = 'block';
    loadCatalog();
  };
}

async function answerFixationQuestion(questionId, selectedAnswer) {
  if (fixationAnswers[questionId] !== undefined) return;
  fixationAnswers[questionId] = selectedAnswer;

  const card = document.getElementById(`fixation-q-${questionId}`);
  const buttons = card.querySelectorAll('.question-option');
  const feedback = document.getElementById(`feedback-${questionId}`);

  buttons.forEach(b => b.disabled = true);

  try {
    const response = await fetch(`/api/study-room/sessions/${currentSession.sessionId}/answer`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ questionId, selectedAnswer })
    });

    const data = await response.json();

    buttons.forEach((b, idx) => {
      if (idx === data.correctIndex) {
        b.style.borderColor = '#10B981';
        b.style.background = 'rgba(16, 185, 129, 0.2)';
      } else if (idx === selectedAnswer && !data.isCorrect) {
        b.style.borderColor = '#EF4444';
        b.style.background = 'rgba(239, 68, 68, 0.2)';
      }
    });

    feedback.style.display = 'block';
    feedback.style.background = data.isCorrect ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)';
    feedback.style.border = `1px solid ${data.isCorrect ? '#10B981' : '#EF4444'}`;
    feedback.innerHTML = `
      <div style="font-weight:700; color:${data.isCorrect ? '#34D399' : '#F87171'}; margin-bottom:0.5rem;">
        ${data.isCorrect ? '✅ Resposta Correta!' : '❌ Resposta Incorreta'}
      </div>
      <div style="font-size:0.9rem; line-height:1.5;">${data.explanation || ''}</div>
    `;

    // Update progress
    const answeredCount = Object.keys(fixationAnswers).length;
    const total = fixationQuestionsList.length;
    document.getElementById('fixation-progress-text').textContent = `${answeredCount} / ${total}`;
    document.getElementById('fixation-progress-bar').style.width = `${(answeredCount / total) * 100}%`;

    if (answeredCount === total) {
      showFixationResults();
    }

  } catch (error) {
    console.error('Answer error:', error);
    showToast('Erro ao registrar resposta.', 'error');
  }
}

function showFixationResults() {
  const resultsDiv = document.getElementById('fixation-results');
  const scoreDiv = document.getElementById('fixation-score');
  const detailsDiv = document.getElementById('fixation-details');

  let correct = 0;
  const total = fixationQuestionsList.length;

  fixationQuestionsList.forEach(q => {
    if (fixationAnswers[q.id] === q.correctIndex) correct++;
  });

  const pct = Math.round((correct / total) * 100);

  scoreDiv.innerHTML = `
    <div class="score-number" style="color: ${pct >= 70 ? '#34D399' : '#FBBF24'};">${correct}/${total}</div>
    <div class="score-detail">${pct}% de aproveitamento nesta aula</div>
  `;

  detailsDiv.innerHTML = `
    <p style="margin-top:0.75rem; color:var(--text-secondary);">
      ${pct >= 80 ? '🎉 Excelente domínio do tema! Aula fixada com sucesso.' : pct >= 60 ? '👍 Bom rendimento. Revise os pontos onde houve dúvida.' : '⚠️ Rendimento abaixo do ideal. Recomendamos agendar uma nova sessão de revisão desta aula.'}
    </p>
  `;

  resultsDiv.style.display = 'block';
  resultsDiv.scrollIntoView({ behavior: 'smooth' });
}
